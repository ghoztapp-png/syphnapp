# Security Specification - Syphn App

## Data Invariants
1. A **User** document's `credit_balance` and `expires_at` can only be updated by the system admin or logically via server endpoints. 
2. A **Post** must have a valid `uid` matching the author.
3. A **DeviceBonus** can only be claimed once per unique device fingerprint.
4. Users cannot delete or modify other users' posts or drafts.

## The Dirty Dozen (Attack Payloads)

1. **Identity Spoofing**: Attempt to create a user document with a different `uid` than the auth token.
2. **Credit Injection**: Attempt to update `credit_balance` directly from the client.
3. **Ghost Field Update**: Attempt to update a user document with an unwhitelisted field (e.g., `isAdmin: true`).
4. **Orphaned Post**: Attempt to create a post without being signed in.
5. **Post Hijacking**: Attempt to update or delete another user's post.
6. **Bonus Reuse**: Attempt to claim a device bonus for an already-used `deviceId`.
7. **Negative Balance**: Attempt to set `credit_balance` to -100.
8. **Resource Poisoning (ID)**: Attempt to use a 2MB string as a `deviceId` or `postId`.
9. **PII Leak**: Attempt to read another user's private data (email, credit balance).
10. **State Skipping**: Attempt to set a post status to `success` without going through `pending`.
11. **Denial of Wallet**: Flooding the system with posts that have negative or zero cost.
12. **Timestamp Forgery**: Sending a post with a `createdAt` date in the future.

## Implementation Details

- **Default Deny**: All paths started with a recursive deny.
- **Path Hardening**: All ID variables are validated for size and type.
- **Server Authority**: Critical billing fields are immutable from client-side SDKs.
- **Type Integrity**: All fields are checked for specific types (string, number, timestamp).
