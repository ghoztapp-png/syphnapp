
/**
 * Adds a "Syphn" watermark to an image file.
 * @param file The original image file.
 * @returns A promise that resolves to a new File object with the watermark.
 */
export async function addWatermarkToImage(file: File): Promise<File> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Could not get canvas context"));
        return;
      }

      // Set canvas dimensions to match image
      canvas.width = img.width;
      canvas.height = img.height;

      // Draw original image
      ctx.drawImage(img, 0, 0);

      // Watermark settings
      const padding = Math.max(canvas.width, canvas.height) * 0.02; // 2% padding
      const fontSize = Math.max(canvas.width, canvas.height) * 0.03; // 3% font size
      
      ctx.font = `bold ${fontSize}px "Outfit", sans-serif`;
      ctx.textBaseline = 'bottom';
      ctx.textAlign = 'right';

      const text = "Sent via Syphn";
      
      // Draw shadow/outline for readability
      ctx.shadowColor = "rgba(0, 0, 0, 0.5)";
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 2;

      // Draw white text
      ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
      ctx.fillText(text, canvas.width - padding, canvas.height - padding);

      // Convert to blob
      canvas.toBlob((blob) => {
        if (blob) {
          const watermarkedFile = new File([blob], file.name, { type: file.type });
          URL.revokeObjectURL(img.src);
          resolve(watermarkedFile);
        } else {
          reject(new Error("Canvas toBlob failed"));
        }
      }, file.type, 0.9);
    };

    img.onerror = () => {
      reject(new Error("Failed to load image for watermarking"));
    };
  });
}
