import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, Users, DollarSign, Activity, AlertCircle, Shield, ShieldOff, CheckCircle2, AlertTriangle, BarChart3 } from 'lucide-react';
import { cn } from '../lib/utils';
import { getMonthlyUsage, getTopHeavyHitters, getSystemConfig, updateSystemConfig, getAdminMetrics } from '../services/api';

export function AdminDashboard({ theme }: { theme: any }) {
  const [usage, setUsage] = useState<any>(null);
  const [topUsers, setTopUsers] = useState<any[]>([]);
  const [config, setConfig] = useState<any>(null);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [usageData, heavyHitters, appConfig, adminMetrics] = await Promise.all([
        getMonthlyUsage(),
        getTopHeavyHitters(),
        getSystemConfig(),
        getAdminMetrics()
      ]);
      setUsage(usageData);
      setTopUsers(heavyHitters);
      setConfig(appConfig);
      setMetrics(adminMetrics);
      setLoading(false);
    } catch (error) {
      console.error("Failed to fetch admin data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleTogglePause = async () => {
    const newPause = !config?.pauseFreeCredits;
    try {
      await updateSystemConfig({ pauseFreeCredits: newPause });
      setConfig({ ...config, pauseFreeCredits: newPause });
    } catch (error) {
      console.error("Failed to update config:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Activity className="w-8 h-8 text-theme-text animate-spin opacity-20" />
      </div>
    );
  }

  const capacity = 10000;
  const used = metrics?.totalPosts || 0;
  const usagePercentage = (used / capacity) * 100;
  
  let gaugeColor = "bg-emerald-500";
  let gaugeText = "text-emerald-500";
  if (used > 9000) {
    gaugeColor = "bg-rose-500";
    gaugeText = "text-rose-500";
  } else if (used > 7500) {
    gaugeColor = "bg-amber-500";
    gaugeText = "text-amber-500";
  }

  const revenueDollars = metrics?.totalRevenueUsd || 0;
  const apiCost = 100;
  const netProfit = metrics?.netProfit || 0;

  return (
    <div className="space-y-12">
      {/* Monthly Capacity Gauge */}
      <section className="bg-theme-text/5 border border-theme-border rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden">
        <div className="relative z-10 space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h2 className="text-xl md:text-2xl font-display font-black text-theme-text uppercase tracking-tight">Monthly Post Capacity</h2>
              <p className="text-xs md:text-sm text-theme-subtext font-semibold">Active usage across all users for {usage?.month}</p>
            </div>
            <div className={cn("text-3xl md:text-4xl font-mono font-black tracking-tighter", gaugeText)}>
              {used.toLocaleString()} / {capacity.toLocaleString()}
            </div>
          </div>

          <div className="h-6 w-full bg-theme-text/10 rounded-full overflow-hidden border border-theme-border p-1">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(100, usagePercentage)}%` }}
              className={cn("h-full rounded-full shadow-lg transition-colors duration-500", gaugeColor)}
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", used > 7500 ? "bg-theme-text/20" : "bg-emerald-500")} />
              <span className="text-[10px] font-black uppercase text-theme-subtext tracking-widest">Normal (&lt;7.5k)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", used > 7500 && used <= 9000 ? "bg-amber-500" : "bg-theme-text/20")} />
              <span className="text-[10px] font-black uppercase text-theme-subtext tracking-widest">Warning (7.5k-9k)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full", used > 9000 ? "bg-rose-500" : "bg-theme-text/20")} />
              <span className="text-[10px] font-black uppercase text-theme-subtext tracking-widest">Critical (&gt;9k)</span>
            </div>
          </div>
        </div>

        {/* Decorative background intensity */}
        <div className={cn(
          "absolute inset-0 opacity-[0.03] pointer-events-none transition-colors duration-500",
          gaugeColor
        )} />
      </section>

      {/* Money View */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-theme-text/5 border border-theme-border rounded-[2rem] p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center">
            <DollarSign className="w-6 h-6 text-emerald-500" />
          </div>
          <div>
            <div className="text-[10px] text-theme-subtext uppercase tracking-[0.2em] font-black mb-1">Gross Revenue</div>
            <div className="text-3xl font-mono font-bold text-theme-text">${revenueDollars.toFixed(2)}</div>
          </div>
        </div>

        <div className="bg-theme-text/5 border border-theme-border rounded-[2rem] p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 flex items-center justify-center">
            <AlertCircle className="w-6 h-6 text-rose-500" />
          </div>
          <div>
            <div className="text-[10px] text-theme-subtext uppercase tracking-[0.2em] font-black mb-1">API Cost</div>
            <div className="text-3xl font-mono font-bold text-theme-text">${apiCost.toFixed(2)}</div>
          </div>
        </div>

        <div className="bg-theme-text/5 border border-theme-border rounded-[2rem] p-8 space-y-4 relative overflow-hidden group">
          <div className="w-12 h-12 rounded-2xl bg-theme-text/10 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-theme-text" />
          </div>
          <div className="relative z-10">
            <div className="text-[10px] text-theme-subtext uppercase tracking-[0.2em] font-black mb-1">Net Profit</div>
            <div className={cn(
              "text-3xl font-mono font-bold",
              netProfit >= 0 ? "text-emerald-500" : "text-rose-500"
            )}>
              ${netProfit.toFixed(2)}
            </div>
            <p className="text-[10px] text-theme-subtext mt-2 font-medium">After $100 fee + 3% Stripe fees</p>
          </div>
        </div>
      </div>

      {/* User Activity & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Heavy Hitters */}
        <div className="lg:col-span-2 bg-theme-text/5 border border-theme-border rounded-[2.5rem] p-10 space-y-8">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-theme-text" />
            <h3 className="text-xl font-display font-black text-theme-text uppercase tracking-tight">Top 10 Heavy Hitters</h3>
          </div>

          <div className="space-y-4">
            {topUsers.map((hitter: any, index: number) => (
              <div 
                key={hitter.id}
                className="flex items-center justify-between p-5 bg-theme-bg/40 border border-theme-border rounded-2xl group hover:border-theme-text/30 transition-all"
              >
                <div className="flex items-center gap-5">
                  <div className="w-10 h-10 rounded-xl bg-theme-text/10 flex items-center justify-center text-xs font-black text-theme-text opacity-40 group-hover:opacity-100 transition-opacity">
                    #{index + 1}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-theme-text">{hitter.email}</div>
                    <div className="text-[10px] text-theme-subtext font-medium uppercase tracking-widest">{hitter.uid.slice(0, 8)}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-mono font-bold text-theme-text">{hitter.postCount || 0}</div>
                  <div className="text-[9px] text-theme-subtext uppercase font-black tracking-widest">Broadcasts</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Security Controls */}
        <div className="space-y-6">
          <div className="bg-theme-text/5 border border-theme-border rounded-[2.5rem] p-10 space-y-8 h-full">
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-theme-text" />
              <h3 className="text-xl font-display font-black text-theme-text uppercase tracking-tight">Controls</h3>
            </div>

            <div className="space-y-8">
              <div className="p-6 bg-theme-bg/40 border border-theme-border rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-theme-text uppercase tracking-widest">Free Initial Credits</span>
                  <button 
                    onClick={handleTogglePause}
                    className={cn(
                      "relative w-12 h-6 rounded-full transition-colors duration-300 focus:outline-none",
                      config?.pauseFreeCredits ? "bg-rose-500" : "bg-emerald-500"
                    )}
                  >
                    <motion.div 
                      animate={{ x: config?.pauseFreeCredits ? 26 : 2 }}
                      className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-lg"
                    />
                  </button>
                </div>
                <div className="flex items-start gap-3">
                  {config?.pauseFreeCredits ? (
                    <ShieldOff className="w-5 h-5 text-rose-500 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                  )}
                  <p className="text-[11px] text-theme-subtext leading-relaxed font-medium">
                    {config?.pauseFreeCredits 
                      ? "Free credits are currently PAUSED. New users start with 0." 
                      : "New users receive 20 free credits ($2.00) on signup."}
                  </p>
                </div>
              </div>

              <div className="p-6 bg-theme-bg/40 border border-theme-border rounded-2xl flex items-start gap-4">
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                <div className="space-y-2">
                  <h4 className="text-[10px] font-black text-theme-text uppercase tracking-widest">System Health</h4>
                  <p className="text-[11px] text-theme-subtext font-medium leading-tight">
                    API usage is currently at {usagePercentage.toFixed(1)}%. Monitor closely as you approach 90%.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
