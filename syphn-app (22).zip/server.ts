import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { initializeApp, getApps, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import firebaseConfigJson from "./firebase-applet-config.json";

dotenv.config();

// Initialize Firebase Admin
let db: any = null;

if (!getApps().length) {
  try {
    let app;
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
      app = initializeApp({
        credential: cert(serviceAccount)
      });
    } else {
      app = initializeApp();
    }
    
    if (app) {
      const configDbId = firebaseConfigJson.firestoreDatabaseId;
      const dbId = (configDbId && configDbId !== "(default)" && configDbId !== "default") ? configDbId : undefined;
      console.log(`Firebase Admin: Initializing Firestore with Database ID: ${dbId || "(default)"}`);
      db = getFirestore(app, dbId);
    }
  } catch (error) {
    console.error("Firebase Admin initialization failed:", error);
  }
} else {
  const app = getApps()[0];
  const configDbId = firebaseConfigJson.firestoreDatabaseId;
  const dbId = (configDbId && configDbId !== "(default)" && configDbId !== "default") ? configDbId : undefined;
  console.log(`Firebase Admin: Using existing app, Firestore Database ID: ${dbId || "(default)"}`);
  db = getFirestore(app, dbId);
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Simple GET endpoint for status check
  app.get("/api/status", (req, res) => {
    const syphnSet = !!process.env.SYPHN_API_KEY;
    const bundleSet = !!process.env.BUNDLE_SOCIAL_API_KEY;
    console.log(`[Status Check] SYPHN: ${syphnSet ? "SET" : "NOT SET"}, BUNDLE: ${bundleSet ? "SET" : "NOT SET"}`);
    res.json({ 
      mode: (syphnSet || bundleSet) ? "production" : "demo",
      apis: {
        syphn: syphnSet,
        bundle: bundleSet
      },
      timestamp: new Date().toISOString()
    });
  });

  // API Route to handle post uploads securely
  app.post("/api/connect-social", async (req, res) => {
    const { platform, uid } = req.body;
    const bundleKey = process.env.BUNDLE_SOCIAL_API_KEY;

    if (!bundleKey) {
      return res.json({ error: "Missing Bundle API Key", simulate: true });
    }

    // This is where you would typically call Bundle Social's API
    // to generate an OAuth redirect link for the specific platform.
    // e.g. api.bundle.social/v1/auth/connect or similar.
    // 
    // Since we don't have the exact Bundle Social docs endpoint,
    // we'll return a placeholder redirect that would be used.
    
    console.log(`[Bundle Social] Requested connection for ${platform} for user ${uid}`);
    
    // Simulate what the response might be. Since we don't have the real oauth URL,
    // we just fallback to our native simulation so the user isn't stuck with a 404.
    res.json({
      success: true,
      simulate: true
    });
  });

  app.post("/api/upload-post", async (req, res) => {
    const { content, channels, media, checkOnly } = req.body;
    const syphnKey = process.env.SYPHN_API_KEY;
    const bundleKey = process.env.BUNDLE_SOCIAL_API_KEY;

    if (checkOnly) {
      return res.json({ 
        success: true, 
        mode: (syphnKey || bundleKey) ? "production" : "demo",
        apis: { syphn: !!syphnKey, bundle: !!bundleKey }
      });
    }

    try {
      let results: any = {};
      
      // 1. Handle Syphn if key exists
      if (syphnKey) {
        console.log("Server: Posting via Syphn API...");
        try {
          const syphnResponse = await fetch("https://syphn.app/api/v1/broadcasts", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${syphnKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ content, channels, media })
          });
          results.syphn = await syphnResponse.json().catch(() => ({ error: "Failed to parse Syphn response" }));
        } catch (err: any) {
          results.syphn = { error: err.message };
        }
      }

      // 2. Handle Bundle Social if key exists
      if (bundleKey) {
        console.log("Server: Posting via Bundle Social API...");
        try {
          // Note: Bundle Social endpoint typically requires 'text' instead of 'content' 
          // and specific channel mapping. Adjusting for compatibility.
          const bundleResponse = await fetch("https://api.bundle.social/v1/posts", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${bundleKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ 
              text: content,
              platforms: channels, // Bundle uses 'platforms'
              media: media 
            })
          });
          results.bundle = await bundleResponse.json().catch(() => ({ error: "Failed to parse Bundle response" }));
        } catch (err: any) {
          results.bundle = { error: err.message };
        }
      }

      // 3. Demo Mode if no keys provide
      if (!syphnKey && !bundleKey) {
        console.log("Server: Running in DEMO MODE");
        await new Promise(resolve => setTimeout(resolve, 1500));
        results.demo = { success: true, message: "Demo post successful" };
      }
      
      res.json({ 
        success: true,
        results, 
        mode: (syphnKey || bundleKey) ? "production" : "demo" 
      });
    } catch (error: any) {
      console.error("Server: Post upload failed:", error);
      res.status(500).json({ error: error.message || "Failed to upload post" });
    }
  });

  // Secure Replenish Endpoint (Simulates what a webhook or cloud function would do)
  app.post("/api/replenish-credits", async (req, res) => {
    const { amount, uid } = req.body; // In real usage, UID comes from auth token
    
    if (!db) {
      console.log("Server: Running in DEMO MODE for replenishment");
      return res.json({ success: true, message: "Demo replenishment successful" });
    }

    try {
      const userRef = db.collection("users").doc(uid);
      const userSnap = await userRef.get();
      
      if (!userSnap.exists) {
        return res.status(404).json({ error: "User not found" });
      }

      const currentBalance = userSnap.data()?.credit_balance || 0;
      const newBalance = currentBalance + amount;
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

      await userRef.update({
        credit_balance: newBalance,
        expires_at: expiresAt,
        isPaid: true
      });

      // Log payment
      await db.collection("payments").add({
        uid,
        amount_usd: amount * 0.1, // assuming $0.10 per credit
        credits_added: amount,
        createdAt: new Date().toISOString()
      });

      res.json({ success: true, newBalance, expiresAt });
    } catch (error: any) {
      console.error("Replenishment failed:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Stripe Webhook Placeholder
  app.post("/api/webhooks/stripe", express.raw({ type: 'application/json' }), async (req, res) => {
    // 1. Verify Stripe signature
    // 2. Extract user UID and purchase amount
    // 3. Call the logic above (Update credit_balance and expires_at)
    console.log("Stripe Event Received");
    res.json({ received: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
