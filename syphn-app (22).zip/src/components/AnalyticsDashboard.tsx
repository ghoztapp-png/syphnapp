import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  Users, 
  MessageSquare, 
  Share2, 
  Heart, 
  ArrowUpRight, 
  ArrowDownRight,
  Filter,
  Calendar,
  Twitter,
  Instagram,
  Facebook,
  Linkedin,
  Youtube,
  Music2,
  Pin,
  AtSign
} from 'lucide-react';
import { collection, query, where, getDocs, orderBy, limit, getDocFromServer, doc as firestoreDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

import { handleFirestoreError, OperationType } from '../lib/firebaseUtils';

const PLATFORM_ICONS: Record<string, any> = {
  twitter: Twitter,
  instagram: Instagram,
  facebook: Facebook,
  linkedin: Linkedin,
  youtube: Youtube,
  tiktok: Music2,
  pinterest: Pin,
  threads: AtSign
};

const PLATFORM_COLORS: Record<string, string> = {
  twitter: '#0ea5e9',
  instagram: '#ec4899',
  facebook: '#2563eb',
  linkedin: '#1d4ed8',
  youtube: '#dc2626',
  tiktok: '#000000',
  pinterest: '#e60023',
  threads: '#000000'
};

interface MetricCardProps {
  title: string;
  value: string | number;
  change: number;
  icon: any;
  label: string;
}

function MetricCard({ title, value, change, icon: Icon, label }: MetricCardProps) {
  const isPositive = change >= 0;
  
  return (
    <div className="bg-white/60 backdrop-blur-sm border border-theme-border rounded-2xl p-4 md:p-6 space-y-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="p-2 bg-theme-text/5 rounded-xl border border-theme-border/50">
          <Icon className="w-4 md:w-5 h-4 md:h-5 text-theme-text/60" />
        </div>
        <div className={cn(
          "flex items-center gap-1 px-2 py-1 rounded-full text-[9px] md:text-[10px] font-black uppercase tracking-wider",
          isPositive ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500"
        )}>
          {isPositive ? <ArrowUpRight className="w-2.5 md:w-3 h-2.5 md:h-3" /> : <ArrowDownRight className="w-2.5 md:w-3 h-2.5 md:h-3" />}
          {Math.abs(change)}%
        </div>
      </div>
      <div>
        <div className="text-[9px] md:text-[10px] text-theme-subtext uppercase tracking-widest font-black mb-1">{title}</div>
        <div className="text-2xl md:text-3xl font-mono font-bold tracking-tight text-theme-text">{value}</div>
        <div className="text-[9px] md:text-[10px] text-theme-subtext/60 font-medium mt-2">{label}</div>
      </div>
    </div>
  );
}

export default function AnalyticsDashboard({ theme }: { theme: any }) {
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');
  const [platformData, setPlatformData] = useState<any[]>([]);
  const [engagementData, setEngagementData] = useState<any[]>([]);
  const [summary, setSummary] = useState({
    totalReach: 0,
    totalEngagement: 0,
    avgEngagementRate: 0,
    totalPosts: 0
  });

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const user = auth.currentUser;
      if (!user) return;

      // Test connection
      try {
        await getDocFromServer(firestoreDoc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }

      // In a real app, we'd fetch actual metrics from an API.
      // For this demo, we'll fetch the user's posts and generate realistic mock metrics based on post age and content.
      const path = "posts";
      let posts: any[] = [];
      try {
        const postsQuery = query(
          collection(db, path),
          where("uid", "==", user.uid),
          orderBy("createdAt", "desc"),
          limit(50)
        );
        
        const snapshot = await getDocs(postsQuery);
        posts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, path);
      }

      // Generate mock data for the dashboard
      const platforms = ['twitter', 'instagram', 'facebook', 'linkedin', 'youtube', 'tiktok', 'pinterest', 'threads'];
      
      const platformMetrics = platforms.map(p => {
        const platformPosts = posts.filter((post: any) => post.platforms?.includes(p));
        const count = platformPosts.length;
        return {
          name: p.charAt(0).toUpperCase() + p.slice(1),
          id: p,
          posts: count,
          likes: count * Math.floor(Math.random() * 100 + 50),
          shares: count * Math.floor(Math.random() * 20 + 5),
          comments: count * Math.floor(Math.random() * 15 + 2),
        };
      }).filter(p => p.posts > 0 || Math.random() > 0.5); // Keep some variety

      setPlatformData(platformMetrics);

      // Generate time-series data
      const days = timeRange === '7d' ? 7 : 30;
      const timeSeries = Array.from({ length: days }).map((_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (days - 1 - i));
        return {
          date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          engagement: Math.floor(Math.random() * 500 + 200),
          reach: Math.floor(Math.random() * 2000 + 1000),
        };
      });
      setEngagementData(timeSeries);

      // Calculate summary
      const totalLikes = platformMetrics.reduce((acc, p) => acc + p.likes, 0);
      const totalShares = platformMetrics.reduce((acc, p) => acc + p.shares, 0);
      const totalComments = platformMetrics.reduce((acc, p) => acc + p.comments, 0);
      
      setSummary({
        totalReach: platformMetrics.reduce((acc, p) => acc + (p.likes * 10), 0),
        totalEngagement: totalLikes + totalShares + totalComments,
        avgEngagementRate: 4.2,
        totalPosts: posts.length
      });

    } catch (error) {
      console.error("Error fetching analytics:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 space-y-4">
        <TrendingUp className="w-8 h-8 text-theme-text animate-pulse opacity-20" />
        <p className="text-[10px] font-black uppercase tracking-widest text-theme-subtext">Crunching data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 md:space-y-12 pb-24 px-4 md:px-0">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-mono font-bold tracking-tight text-theme-text [text-shadow:var(--text-shadow-theme)]">Performance</h2>
          <p className="text-theme-subtext text-xs md:text-sm mt-1">Real-time insights across your broadcast network.</p>
        </div>
        
        <div className="flex items-center gap-1 p-1 bg-theme-bg/40 border border-theme-border rounded-xl w-fit">
          {['7d', '30d', '90d'].map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={cn(
                "px-3 md:px-4 py-1.5 rounded-lg text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all",
                timeRange === range 
                  ? "bg-theme-text text-theme-bg shadow-lg" 
                  : "text-theme-subtext hover:text-theme-text"
              )}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          title="Total Reach" 
          value={summary.totalReach.toLocaleString()} 
          change={12.5} 
          icon={Users}
          label="Unique impressions"
        />
        <MetricCard 
          title="Engagement" 
          value={summary.totalEngagement.toLocaleString()} 
          change={8.2} 
          icon={Heart}
          label="Likes, shares & comments"
        />
        <MetricCard 
          title="Eng. Rate" 
          value={`${summary.avgEngagementRate}%`} 
          change={-2.4} 
          icon={TrendingUp}
          label="Interaction per reach"
        />
        <MetricCard 
          title="Total Posts" 
          value={summary.totalPosts} 
          change={15.0} 
          icon={MessageSquare}
          label="Broadcasts sent"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Engagement Over Time */}
        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 md:p-8 space-y-6 md:space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base md:text-lg font-bold tracking-tight">Engagement Trend</h3>
              <p className="text-[10px] md:text-xs text-theme-subtext">Daily interactions over time</p>
            </div>
            <TrendingUp className="w-5 h-5 text-theme-text/40" />
          </div>
          
          <div className="h-[250px] md:h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={engagementData}>
                <defs>
                  <linearGradient id="colorEng" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="currentColor" stopOpacity={0.3} className="text-theme-text" />
                    <stop offset="95%" stopColor="currentColor" stopOpacity={0} className="text-theme-text" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: theme.isLight ? '#00000060' : '#ffffff40', fontWeight: 700 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: theme.isLight ? '#00000060' : '#ffffff40', fontWeight: 700 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: theme.isLight ? '#fff' : '#000', 
                    border: `1px solid ${theme.isLight ? '#00000010' : '#ffffff10'}`, 
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 700
                  }}
                  itemStyle={{ color: theme.isLight ? '#000' : '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="engagement" 
                  stroke="currentColor" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorEng)"
                  className="text-theme-text"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Platform Distribution */}
        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 md:p-8 space-y-6 md:space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base md:text-lg font-bold tracking-tight">Platform Distribution</h3>
              <p className="text-[10px] md:text-xs text-theme-subtext">Performance by channel</p>
            </div>
            <Filter className="w-5 h-5 text-theme-text/40" />
          </div>
          
          <div className="h-[250px] md:h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platformData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  axisLine={false} 
                  tickLine={false}
                  tick={{ fontSize: 10, fill: theme.isLight ? '#000000' : '#ffffff', fontWeight: 900, textTransform: 'uppercase' }}
                  width={80}
                />
                <Tooltip 
                  cursor={{ fill: theme.isLight ? '#00000005' : '#ffffff05' }}
                  contentStyle={{ 
                    backgroundColor: theme.isLight ? '#fff' : '#000', 
                    border: `1px solid ${theme.isLight ? '#00000010' : '#ffffff10'}`, 
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 700
                  }}
                />
                <Bar 
                  dataKey="likes" 
                  radius={[0, 4, 4, 0]} 
                  barSize={20}
                >
                  {platformData.map((entry, index) => (
                    <rect 
                      key={`cell-${index}`} 
                      fill={PLATFORM_COLORS[entry.id] || '#ffffff20'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top Posts Table */}
      <div className="bg-theme-bg/40 border border-theme-border rounded-3xl overflow-hidden">
        <div className="p-6 md:p-8 border-b border-theme-border flex items-center justify-between">
          <div>
            <h3 className="text-base md:text-lg font-bold tracking-tight">Top Performing Posts</h3>
            <p className="text-[10px] md:text-xs text-theme-subtext">Highest engagement broadcasts</p>
          </div>
          <button className="text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext hover:text-theme-text transition-colors">View All</button>
        </div>
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-collapse min-w-[600px] md:min-w-0">
            <thead>
              <tr className="bg-theme-text/5">
                <th className="px-6 md:px-8 py-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext">Content</th>
                <th className="px-6 md:px-8 py-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext">Platforms</th>
                <th className="px-6 md:px-8 py-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext text-right">Likes</th>
                <th className="px-6 md:px-8 py-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext text-right">Shares</th>
                <th className="px-6 md:px-8 py-4 text-[9px] md:text-[10px] font-black uppercase tracking-widest text-theme-subtext text-right">Engagement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-theme-border">
              {[1, 2, 3, 4, 5].map((i) => (
                <tr key={i} className="hover:bg-theme-text/5 transition-colors group">
                  <td className="px-6 md:px-8 py-4 md:py-6">
                    <div className="max-w-[200px] md:max-w-xs truncate font-medium text-xs md:text-sm">
                      {i === 1 ? "🚀 Just launched our new AI-powered dashboard! Check it out..." : 
                       i === 2 ? "Big news coming tomorrow! Stay tuned for the reveal. #exciting" :
                       i === 3 ? "How we scaled our infrastructure to handle 1M requests per second." :
                       i === 4 ? "The future of social media is decentralized. Here's why." :
                       "Weekly roundup: Top 10 tech stories you might have missed."}
                    </div>
                    <div className="text-[9px] md:text-[10px] text-theme-subtext/60 mt-1 font-bold uppercase tracking-wider">2 days ago</div>
                  </td>
                  <td className="px-6 md:px-8 py-4 md:py-6">
                    <div className="flex gap-1.5 md:gap-2">
                      {['twitter', 'linkedin', 'instagram'].map(p => {
                        const Icon = PLATFORM_ICONS[p];
                        return Icon ? <Icon key={p} className={cn("w-3 md:w-3.5 h-3 md:h-3.5", PLATFORM_COLORS[p] ? `text-[${PLATFORM_COLORS[p]}]` : "text-theme-text/40")} /> : null;
                      })}
                    </div>
                  </td>
                  <td className="px-6 md:px-8 py-4 md:py-6 text-right font-mono font-bold text-xs md:text-sm">{(1200 / i).toFixed(0)}</td>
                  <td className="px-6 md:px-8 py-4 md:py-6 text-right font-mono font-bold text-xs md:text-sm">{(450 / i).toFixed(0)}</td>
                  <td className="px-6 md:px-8 py-4 md:py-6 text-right">
                    <div className="inline-flex items-center gap-1 md:gap-1.5 px-2 py-1 bg-emerald-500/10 text-emerald-500 rounded-lg text-[9px] md:text-[10px] font-black uppercase tracking-wider">
                      <TrendingUp className="w-2.5 md:w-3 h-2.5 md:h-3" />
                      +{Math.floor(Math.random() * 20 + 5)}%
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
