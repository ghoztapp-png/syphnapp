import React, { useState, useEffect, useRef } from "react";
import { toast, Toaster } from 'sonner';
import { auth, login, logout, db } from "./firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import { useDocument } from "react-firebase-hooks/firestore";
import { doc as firestoreDoc, collection, query, where, orderBy, limit, onSnapshot, addDoc, deleteDoc, getDocs, serverTimestamp } from "firebase/firestore";
import { handleFirestoreError, OperationType } from "./lib/firebaseUtils";
import { motion, AnimatePresence } from "motion/react";
import { 
  Send, 
  History, 
  CreditCard, 
  LogOut, 
  Plus, 
  Minus,
  CheckCircle2, 
  AlertCircle, 
  Twitter, 
  Instagram, 
  Facebook, 
  Linkedin,
  Youtube,
  Music2,
  Pin,
  AtSign,
  Loader2,
  Calendar,
  Clock,
  Eye,
  X,
  Image as ImageIcon,
  Film,
  Trash2,
  User as UserIcon,
  ChevronRight,
  ChevronLeft,
  Info,
  TrendingUp,
  Activity,
  Filter,
  Key,
  Shield,
  RefreshCw,
  ArrowUpRight,
  ExternalLink,
  Share2,
  Zap,
  ShieldCheck,
  Link2,
  BarChart3,
  Share2 as ShareIcon
} from "lucide-react";
import { 
  addHours, 
  addDays, 
  startOfHour, 
  format, 
  startOfTomorrow, 
  nextMonday, 
  setHours, 
  setMinutes,
  isSameDay,
  addWeeks,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  getDay,
  isToday,
  isPast
} from 'date-fns';
import { cn } from "./lib/utils";
import { uploadPost, topUpCredits, subtractCredits, deletePost, toggleConnection, removeAccount, ensureUserProfile, getApiStatus, isAccessActive, getAdminMetrics, replenishCreditsSecurely } from "./services/api";

// --- Components ---

import { addWatermarkToImage } from "./lib/mediaUtils";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import { AdminDashboard } from "./components/AdminDashboard";

const PLATFORMS = [
  { 
    id: "twitter", 
    name: "Twitter / X", 
    icon: Twitter, 
    color: "text-sky-500", 
    brand: "sky-500", 
    limit: 280, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Authorize Syphn on X", "Start broadcasting"],
    signupUrl: "https://twitter.com/i/flow/signup"
  },
  { 
    id: "instagram", 
    name: "Instagram", 
    icon: Instagram, 
    color: "text-pink-500", 
    brand: "pink-500", 
    limit: 2200, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Login to Instagram", "Allow media access"],
    signupUrl: "https://www.instagram.com/accounts/emailsignup/"
  },
  { 
    id: "facebook", 
    name: "Facebook", 
    icon: Facebook, 
    color: "text-blue-600", 
    brand: "blue-600", 
    limit: 5000, 
    handlePrefix: "",
    guide: ["Click 'Connect'", "Select your Page", "Grant permissions"],
    signupUrl: "https://www.facebook.com/r.php"
  },
  { 
    id: "linkedin", 
    name: "LinkedIn", 
    icon: Linkedin, 
    color: "text-blue-700", 
    brand: "blue-700", 
    limit: 3000, 
    handlePrefix: "in/",
    guide: ["Click 'Connect'", "Sign in to LinkedIn", "Confirm connection"],
    signupUrl: "https://www.linkedin.com/signup"
  },
  { 
    id: "youtube", 
    name: "YouTube", 
    icon: Youtube, 
    color: "text-red-600", 
    brand: "red-600", 
    limit: 5000, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Choose Google account", "Allow channel access"],
    signupUrl: "https://accounts.google.com/signup"
  },
  { 
    id: "tiktok", 
    name: "TikTok", 
    icon: Music2, 
    color: "text-cyan-400", 
    brand: "cyan-400", 
    limit: 2200, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Open TikTok app", "Scan QR or Login"],
    signupUrl: "https://www.tiktok.com/signup"
  },
  { 
    id: "pinterest", 
    name: "Pinterest", 
    icon: Pin, 
    color: "text-red-500", 
    brand: "red-500", 
    limit: 500, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Login to Pinterest", "Authorize app"],
    signupUrl: "https://www.pinterest.com/signup/"
  },
  { 
    id: "threads", 
    name: "Threads", 
    icon: AtSign, 
    color: "text-theme-text", 
    brand: "currentColor", 
    limit: 500, 
    handlePrefix: "@",
    guide: ["Click 'Connect'", "Link via Instagram", "Confirm Threads access"],
    signupUrl: "https://www.threads.net/login"
  },
];

const THEMES = [
  { id: "sky", name: "Azure Sky", bg: "bg-[#F0F7FF]", hex: "#F0F7FF", isLight: true },
  { id: "slate", name: "Midnight Slate", bg: "bg-[#0F172A]", hex: "#0F172A" },
];

export default function App() {
  const [user, loading, error] = useAuthState(auth);
  const [theme, setTheme] = useState(THEMES[0]);
  const [activeUtility, setActiveUtility] = useState<"Terms" | "Privacy" | "Refunds" | "Status" | null>(null);
  const [userProfile, profileLoading] = useDocument(
    user ? firestoreDoc(db, "users", user.uid) : null
  );

  useEffect(() => {
    if (user) {
      ensureUserProfile();
    }
  }, [user]);

  if (loading) {
    return (
      <div className={cn("min-h-screen flex items-center justify-center transition-colors duration-500", theme.bg)}>
        <Loader2 className="w-8 h-8 text-theme-text animate-spin opacity-20" />
      </div>
    );
  }

  return (
    <div 
      className={cn(
        "min-h-screen text-theme-text font-sans selection:bg-theme-text/10 transition-colors duration-500 relative", 
        !theme.isLight && "theme-dark"
      )}
      style={{ backgroundColor: theme.hex }}
    >
      <Toaster position="top-center" />
      {/* Background Overlay for Contrast */}
      <div className={cn(
        "absolute inset-0 pointer-events-none",
        theme.isLight ? "bg-black/5" : "bg-black/10"
      )} />
      {!user ? (
        <AuthScreen theme={theme} login={login} onUtilityClick={setActiveUtility} />
      ) : (
        <Dashboard 
          user={user} 
          credit_balance={userProfile?.data()?.credit_balance || 0}
          expires_at={userProfile?.data()?.expires_at || null}
          credits={userProfile?.data()?.credits || 0} 
          isPaid={userProfile?.data()?.isPaid || user?.email?.toLowerCase() === 'ghozt.app@gmail.com'}
          connections={userProfile?.data()?.connections || {}}
          theme={theme} 
          logout={logout} 
          onUtilityClick={setActiveUtility}
        />
      )}

      <AnimatePresence>
        {activeUtility && (
          <UtilityModal 
            type={activeUtility} 
            onClose={() => setActiveUtility(null)} 
            theme={theme} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function UtilityModal({ type, onClose, theme }: { type: string, onClose: () => void, theme: any }) {
  const getContent = () => {
    switch(type) {
      case "Terms":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-display font-black uppercase tracking-tight">Terms of Service</h3>
            <p className="text-sm text-theme-subtext leading-relaxed">
              By using Syphn, you agree to our automated broadcasting protocols. Syphn is a tool for professional social media distribution.
            </p>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">1. Acceptable Use</h4>
              <p className="text-xs text-theme-subtext/80">You may not use Syphn to broadcast spam, malware, or prohibited content as defined by target social platforms.</p>
            </div>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">2. Account Responsibility</h4>
              <p className="text-xs text-theme-subtext/80">You are responsible for the security of your account and any broadcasts initiated through your API keys.</p>
            </div>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">3. API Limits</h4>
              <p className="text-xs text-theme-subtext/80">Usage is subject to individual platform API rate limits and our own server capacity constraints.</p>
            </div>
          </div>
        );
      case "Privacy":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-display font-black uppercase tracking-tight">Privacy Policy</h3>
            <p className="text-sm text-theme-subtext leading-relaxed">
              Your data security is our priority. We only store the minimum information required to facilitate social media connections.
            </p>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">Data Collection</h4>
              <p className="text-xs text-theme-subtext/80">We collect your email for account identification and encrypted OAuth tokens for social platform access.</p>
            </div>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">Data Retention</h4>
              <p className="text-xs text-theme-subtext/80">Post history is kept for tracking purposes and can be deleted by the user at any time.</p>
            </div>
          </div>
        );
      case "Refunds":
        return (
          <div className="space-y-4">
            <h3 className="text-xl font-display font-black uppercase tracking-tight">Refund Policy</h3>
            <p className="text-sm text-theme-subtext leading-relaxed">
              Syphn operates on a pay-as-you-go credit system. All sales are final due to the immediate allocation of resources for social broadcasting.
            </p>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">System Errors</h4>
              <p className="text-xs text-theme-subtext/80">If a broadcast fails specifically due to a Syphn internal system error, credits are automatically re-assigned to your balance.</p>
            </div>
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-theme-primary">Third-Party Failures</h4>
              <p className="text-xs text-theme-subtext/80">Failures caused by target platform outages or account bans are not eligible for refunds.</p>
            </div>
          </div>
        );
      case "Status":
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-display font-black uppercase tracking-tight">System Status</h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-theme-subtext mb-1">Core Engine</div>
                  <div className="text-sm font-bold">Syphn Pipeline</div>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-full">
                  <Activity className="w-3 h-3 animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Operational</span>
                </div>
              </div>
              <div className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-theme-subtext mb-1">API Node</div>
                  <div className="text-sm font-bold">Broadcast Gateway</div>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 rounded-full">
                  <ShieldCheck className="w-3 h-3" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Secure</span>
                </div>
              </div>
            </div>
            <p className="text-[10px] text-center text-theme-subtext uppercase font-bold tracking-[0.2em]">
              Latest Update: {new Date().toLocaleDateString()}
            </p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-theme-bg/90 backdrop-blur-md" 
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-md bg-theme-bg border border-theme-border rounded-[32px] shadow-2xl overflow-hidden"
      >
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="p-2 bg-theme-primary/10 rounded-xl">
              <Info className="w-5 h-5 text-theme-primary" />
            </div>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-theme-text/5 rounded-xl transition-colors group"
            >
              <X className="w-5 h-5 text-theme-subtext group-hover:text-theme-text transition-colors" />
            </button>
          </div>
          
          {getContent()}
          
          <button 
            onClick={onClose}
            className="w-full mt-10 py-4 bg-theme-text text-theme-bg rounded-2xl font-black uppercase tracking-widest text-[10px] hover:opacity-90 transition-opacity"
          >
            Close
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function AuthScreen({ theme, login, onUtilityClick }: { theme: any, login: () => void, onUtilityClick: (type: any) => void }) {
  const [loginError, setLoginError] = useState<string | null>(null);

  const handleLogin = async () => {
    setLoginError(null);
    try {
      await login();
    } catch (error: any) {
      if (error.code === 'auth/popup-closed-by-user') return;
      
      console.error("Login Error:", error);
      
      if (error.code === 'auth/popup-blocked') {
        setLoginError("The login popup was blocked by your browser. Please allow popups for this site and try again.");
      } else {
        setLoginError("Authentication failed. Please try again.");
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 md:p-8 relative overflow-hidden bg-theme-bg">
      {/* Dynamic Background Mesh */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
            x: [0, 100, 0],
            y: [0, -50, 0]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className={cn(
            "absolute -top-[20%] -left-[10%] w-[80%] h-[80%] rounded-full blur-[120px]",
            theme.isLight ? "bg-sky-500/20" : "bg-theme-primary/10"
          )} 
        />
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [0, -90, 0],
            x: [0, -100, 0],
            y: [0, 50, 0]
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className={cn(
            "absolute -bottom-[20%] -right-[10%] w-[80%] h-[80%] rounded-full blur-[120px]",
            theme.isLight ? "bg-blue-500/20" : "bg-purple-500/10"
          )} 
        />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none" />
      </div>

      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center relative z-10 min-h-[calc(100vh-100px)]">
        {/* Left Side: Branding & Vision */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="space-y-12 text-center lg:text-left pt-12 md:pt-0"
        >
          <div className="space-y-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-3 px-4 py-2 bg-theme-primary/10 border border-theme-primary/20 rounded-2xl text-[11px] font-black uppercase tracking-[0.3em] text-theme-primary"
            >
              <div className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-theme-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-theme-primary"></span>
              </div>
              The Future of Social Broadcasting
            </motion.div>
            
            <div className="space-y-6">
              <motion.img 
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3, type: "spring", stiffness: 100 }}
                src="https://i.imgur.com/nAOlGZm.png" 
                alt="Syphn Logo" 
                className="h-20 md:h-28 w-auto object-contain mx-auto lg:mx-0 drop-shadow-[0_0_30px_rgba(var(--theme-primary-rgb),0.3)]"
                referrerPolicy="no-referrer"
              />
              <h1 className="text-5xl md:text-7xl font-display font-black tracking-tight leading-[0.9] text-theme-text">
                Broadcast <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-theme-primary via-purple-500 to-cyan-500">
                  Everywhere.
                </span>
              </h1>
              <p className="text-theme-subtext text-lg md:text-xl max-w-lg mx-auto lg:mx-0 leading-relaxed font-medium">
                One click to reach all your audiences. No subscriptions, no limits. Just pure broadcasting power.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { label: "Post Once", sub: "All Socials", icon: Share2 },
              { label: "10¢ / Post", sub: "Pay-as-you-go", icon: Zap },
              { label: "No Monthly", sub: "Subscription Free", icon: ShieldCheck }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.5 + (i * 0.1) }}
                className="p-4 bg-theme-bg-accent border border-theme-border rounded-3xl space-y-2 group hover:border-theme-primary/50 transition-colors"
              >
                <item.icon className="w-5 h-5 text-theme-primary group-hover:scale-110 transition-transform" />
                <div className="space-y-0.5">
                  <div className="text-xs font-black uppercase tracking-wider text-theme-text">{item.label}</div>
                  <div className="text-[10px] uppercase tracking-widest text-theme-subtext font-bold">{item.sub}</div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 1 }}
            className="flex flex-col items-center lg:items-start gap-4 pt-8"
          >
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-theme-bg bg-theme-bg-accent overflow-hidden">
                  <img src={`https://i.pravatar.cc/100?u=${i + 10}`} alt="User" />
                </div>
              ))}
              <div className="w-10 h-10 rounded-full border-2 border-theme-bg bg-theme-primary flex items-center justify-center text-[10px] font-black text-white">4k+</div>
            </div>
            <p className="text-[10px] uppercase tracking-widest font-black text-theme-subtext">Joined by 4,000+ creators this month</p>
          </motion.div>
        </motion.div>

        {/* Right Side: Login Card */}
        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative lg:sticky lg:top-24 mb-12 lg:mb-0"
        >
          {/* Decorative Rings */}
          <div className="absolute -inset-4 border border-theme-primary/10 rounded-[4rem] animate-[spin_20s_linear_infinite] pointer-events-none" />
          <div className="absolute -inset-8 border border-purple-500/5 rounded-[5rem] animate-[spin_30s_linear_infinite_reverse] pointer-events-none" />

          <div className={cn(
            "relative p-1 rounded-[3.5rem] backdrop-blur-3xl",
            theme.isLight 
              ? "bg-gradient-to-br from-theme-primary/10 via-purple-500/10 to-cyan-500/10"
              : "bg-gradient-to-br from-theme-primary/20 via-purple-500/20 to-cyan-500/20"
          )}>
            <div className={cn(
              "p-8 md:p-12 rounded-[3.3rem] space-y-10 shadow-2xl border",
              theme.isLight 
                ? "bg-white/90 border-black/5" 
                : "bg-theme-bg/90 border-white/5"
            )}>
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-display font-bold text-theme-text">Welcome to Syphn</h2>
                <div className="flex items-center justify-center gap-2">
                  <p className="text-theme-subtext text-sm font-medium">Connect with Google to start</p>
                  <div className="h-1 w-1 rounded-full bg-theme-text/20" />
                  <div className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-emerald-500">
                    <Zap className="w-3 h-3 animate-pulse" />
                    Mobile Ready
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <button 
                  onClick={handleLogin}
                  className="group relative w-full py-5 bg-theme-text text-theme-bg font-black uppercase tracking-[0.2em] text-sm rounded-2xl overflow-hidden transition-all hover:scale-[1.02] active:scale-[0.98] shadow-xl"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-theme-primary via-purple-500 to-cyan-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite] pointer-events-none" />
                  <div className="relative flex items-center justify-center gap-4 group-hover:text-white transition-colors">
                    <UserIcon className="w-5 h-5" />
                    Get Started Now
                  </div>
                </button>

                <div className="flex items-center gap-4 py-2">
                  <div className="h-px flex-1 bg-theme-border" />
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-theme-subtext">Limited Offer</span>
                  <div className="h-px flex-1 bg-theme-border" />
                </div>

                <div className={cn(
                  "p-4 rounded-2xl flex items-center gap-4 border",
                  theme.isLight 
                    ? "bg-emerald-500/5 border-emerald-500/20" 
                    : "bg-emerald-500/5 border-emerald-500/10"
                )}>
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0">
                    <Zap className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div className="space-y-0.5">
                    <div className="text-xs font-black uppercase tracking-wider text-emerald-500">20 Free Broadcasts</div>
                    <div className="text-[10px] uppercase tracking-widest text-emerald-500/60 font-bold">For all new accounts</div>
                  </div>
                </div>
              </div>

              {loginError && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-rose-500/5 border border-rose-500/10 rounded-2xl text-[11px] text-rose-500 font-bold uppercase tracking-widest text-center"
                >
                  {loginError}
                </motion.div>
              )}

              <p className="text-[10px] text-center text-theme-subtext font-medium leading-relaxed px-4">
                By signing in, you agree to our{" "}
                <button onClick={() => onUtilityClick("Terms")} className="underline hover:text-theme-primary">Terms of Service</button>
                {" "}and{" "}
                <button onClick={() => onUtilityClick("Privacy")} className="underline hover:text-theme-primary">Privacy Policy</button>.
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Landing Content Sections */}
      <div className="max-w-6xl w-full space-y-32 py-24 relative z-10">
        
        {/* Features Grid */}
        <section className="space-y-16">
          <div className="text-center space-y-4">
            <div className="text-[10px] font-black uppercase tracking-[0.4em] text-theme-primary">The Architecture</div>
            <h2 className="text-4xl md:text-5xl font-display font-black text-theme-text uppercase tracking-tighter">Everything you need to <br/> scale your voice.</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { 
                title: "Simultpost", 
                desc: "Broadcast to Twitter, Instagram, LinkedIn, and more in a single click.",
                icon: Share2,
                color: "bg-blue-500"
              },
              { 
                title: "Smart Scheduler", 
                desc: "Plan weeks of content in minutes. We handle the perfect timing.",
                icon: Calendar,
                color: "bg-purple-500"
              },
              { 
                title: "Deep Analytics", 
                desc: "Real-time performance metrics across all platforms in one dashboard.",
                icon: BarChart3,
                color: "bg-emerald-500"
              }
            ].map((f, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="p-8 bg-theme-bg-accent/40 border border-theme-border rounded-[2.5rem] space-y-6 group hover:bg-theme-bg-accent transition-all"
              >
                <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-current/20", f.color)}>
                  <f.icon className="w-8 h-8" />
                </div>
                <div className="space-y-3">
                  <h3 className="text-xl font-bold text-theme-text">{f.title}</h3>
                  <p className="text-sm text-theme-subtext leading-relaxed">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Pricing Table Section */}
        <section className="space-y-16">
          <div className="text-center space-y-4">
            <div className="text-[10px] font-black uppercase tracking-[0.4em] text-theme-primary">No Monthly Tax</div>
            <h2 className="text-4xl md:text-5xl font-display font-black text-theme-text uppercase tracking-tighter">Pure Pay-As-You-Go.</h2>
            <p className="text-theme-subtext max-w-xl mx-auto font-medium">Why pay $49/mo when you only post twice a week? Pay for exactly what you use, and nothing more.</p>
          </div>

          <div className="relative group max-w-2xl mx-auto">
             <div className="absolute -inset-1 bg-gradient-to-r from-theme-primary via-purple-500 to-cyan-500 rounded-[3rem] blur opacity-20 group-hover:opacity-40 transition-opacity" />
             <div className="relative bg-theme-bg border border-theme-border rounded-[3rem] p-8 md:p-12 overflow-hidden">
                <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="space-y-4 text-center md:text-left">
                    <div className="space-y-1">
                      <div className="text-5xl md:text-7xl font-display font-black text-theme-text leading-none">10¢</div>
                      <div className="text-xs font-black uppercase tracking-[0.2em] text-theme-subtext">Per Broadcast Event</div>
                    </div>
                    <ul className="space-y-3">
                      {["Unlimited Platforms", "No Monthly Minimums", "Priority Server Speed"].map((item, i) => (
                        <li key={i} className="flex items-center gap-3 text-[11px] font-black uppercase tracking-widest text-theme-text/80">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="w-full md:w-auto">
                    <button 
                      onClick={handleLogin}
                      className="w-full md:w-auto px-12 py-6 bg-theme-text text-theme-bg rounded-[2rem] font-black uppercase tracking-widest text-xs hover:scale-105 active:scale-95 transition-all shadow-2xl"
                    >
                      Refill Anytime
                    </button>
                  </div>
                </div>
             </div>
          </div>
        </section>

        {/* Security / FAQ */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="text-[10px] font-black uppercase tracking-[0.4em] text-theme-primary">Your Security</div>
              <h2 className="text-3xl font-display font-black text-theme-text uppercase tracking-tighter">Your passwords are <br /> never ours.</h2>
              <p className="text-theme-subtext text-sm leading-relaxed max-w-md">
                We use secure OAuth 2.0 authentication. Syphn never sees, stores, or touches your social media passwords. You maintain 100% control through the social platforms' own official security portals.
              </p>
            </div>
            <div className="flex items-center gap-6 p-6 bg-emerald-500/5 border border-emerald-500/10 rounded-[2rem]">
               <ShieldCheck className="w-12 h-12 text-emerald-500" />
               <div className="space-y-1">
                 <div className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Enterprise Security</div>
                 <p className="text-xs text-emerald-500/70 font-medium">Bank-grade encryption for all API communication.</p>
               </div>
            </div>
          </div>

          <div className="space-y-4">
            {[
              { q: "Is there a free trial?", a: "Every new account gets 20 free broadcast credits automatically. No credit card required." },
              { q: "Which platforms are supported?", a: "Currently Twitter (X), Instagram, LinkedIn, and Facebook. More coming soon." },
              { q: "Can I cancel anytime?", a: "There is nothing to cancel. Since there's no subscription, simply stop posting whenever you want." },
              { q: "What is your refund policy?", a: "Due to the costs of social media API broadcasting, credits are generally non-refundable once purchased. However, if a post fails due to a system error, your credits are automatically returned to your balance." }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-6 bg-theme-bg-accent/20 border border-theme-border rounded-2xl space-y-2"
              >
                <div className="text-sm font-bold text-theme-text">{item.q}</div>
                <div className="text-xs text-theme-subtext leading-relaxed">{item.a}</div>
              </motion.div>
            ))}
          </div>
        </section>

      </div>

      <div className="w-full relative z-10 pt-12 pb-24 border-t border-theme-border bg-theme-bg/40 backdrop-blur-3xl">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col items-center gap-8 text-center">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-display font-black text-theme-text uppercase">Power Up Your Voice.</h2>
              <p className="text-theme-subtext max-w-lg mx-auto">The only social media tool that rewards you for growing at your own pace.</p>
            </div>
            <button 
              onClick={handleLogin}
              className="px-16 py-6 bg-theme-primary text-white rounded-full font-black uppercase tracking-[0.2em] text-xs hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-theme-primary/20"
            >
              Sign Up For Free Credits
            </button>
            <Footer theme={theme} onUtilityClick={onUtilityClick} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ user, credit_balance, expires_at, credits, isPaid, connections, theme, logout, onUtilityClick }: { user: any, credit_balance: number, expires_at: string | null, credits: number, isPaid: boolean, connections: any, theme: any, logout: () => void, onUtilityClick: (type: any) => void }) {
  const isAdmin = user?.email?.toLowerCase() === 'ghozt.app@gmail.com';
  const isActive = isAccessActive({
    uid: user.uid,
    email: user.email,
    credit_balance,
    expires_at,
    credits,
    postCount: 0,
    deviceId: '',
    isPaid,
    connections,
    createdAt: null
  });
  const [activeTab, setActiveTab] = useState<"overview" | "compose" | "history" | "analytics" | "connections" | "settings">(isAdmin ? "overview" : "compose");
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [packSelections, setPackSelections] = useState<{ [key: string]: number }>({
    small: 0,
    medium: 0,
    large: 0
  });
  const [apiMode, setApiMode] = useState<"demo" | "production">("demo");

  const PACK_CONFIG = [
    { id: "small", label: "50 Credits", amount: 50, price: 500 },
    { id: "medium", label: "100 Credits", amount: 100, price: 1000 },
    { id: "large", label: "300 Credits", amount: 300, price: 2500 }
  ];

  const pendingCredits: number = Object.entries(packSelections).reduce((acc: number, [id, count]) => {
    const pack = PACK_CONFIG.find(p => p.id === id);
    if (!pack) return acc;
    return acc + (pack.amount * (count as number));
  }, 0);

  const pendingCost: number = Object.entries(packSelections).reduce((acc: number, [id, count]) => {
    const pack = PACK_CONFIG.find(p => p.id === id);
    if (!pack) return acc;
    return acc + (pack.price * (count as number));
  }, 0);

  const refreshStatus = async () => {
    const mode = await getApiStatus();
    setApiMode(mode);
  };

  useEffect(() => {
    refreshStatus();
  }, []);

  return (
    <div className="min-h-screen">
      <header className={cn(
        "border-b border-theme-border sticky top-0 z-50 shadow-sm backdrop-blur-md",
        theme.isLight ? "bg-white/60" : "bg-theme-bg/60"
      )}>
        <div className="max-w-5xl mx-auto px-4 md:px-6 py-2 md:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 md:gap-4">
            <div className="space-y-0.5">
              <img 
                src="https://i.imgur.com/nAOlGZm.png" 
                alt="Syphn Logo" 
                className="h-5 md:h-8 w-auto object-contain"
                referrerPolicy="no-referrer"
              />
              <div className={cn(
                "hidden sm:flex items-center gap-2 text-[8px] md:text-[9px] uppercase tracking-[0.2em] font-bold",
                theme.isLight ? "text-black" : "text-theme-subtext"
              )}>
                <div className="w-1 h-1 md:w-1.5 md:h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Network Active
              </div>
            </div>

            <div className={cn(
              "px-1.5 md:px-2 py-0.5 rounded-full text-[6px] md:text-[8px] font-black uppercase tracking-widest border",
              apiMode === "production" 
                ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                : "bg-amber-500/10 text-amber-500 border-amber-500/20"
            )}>
              {apiMode === "production" ? "Live" : "Demo"}
            </div>

            {!isPaid && expires_at && (
              <CountdownTimer expiresAt={expires_at} theme={theme} />
            )}
          </div>

          <div className="flex items-center gap-2 md:gap-6">
            <div className="text-right">
              <div className={cn(
                "hidden sm:block text-[8px] md:text-[9px] uppercase tracking-widest font-black mb-0.5",
                theme.isLight ? "text-black" : "text-theme-subtext"
              )}>Balance</div>
              <div className="flex items-center gap-1.5 md:gap-2">
                <span className={cn(
                  "text-xs md:text-lg font-mono font-bold tracking-tight",
                  theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]",
                  credits === 0 && user?.email?.toLowerCase() !== 'ghozt.app@gmail.com' && "text-rose-500 animate-pulse"
                )}>
                  {user?.email?.toLowerCase() === 'ghozt.app@gmail.com' ? "∞" : `$${(credits / 100).toFixed(2)}`}
                </span>
                <button 
                  onClick={() => setIsTopUpOpen(true)}
                  className={cn(
                    "p-1 md:p-1.5 border rounded-lg transition-all shadow-sm",
                    theme.isLight ? "bg-white hover:bg-gray-50 border-black/10" : "bg-theme-text/10 hover:bg-theme-text/20 border-theme-border"
                  )}
                >
                  <Plus className={cn("w-2.5 md:w-3.5 h-2.5 md:h-3.5", theme.isLight ? "text-black" : "text-theme-text")} />
                </button>
              </div>
            </div>
            
            <div className="h-6 md:h-8 w-[1px] bg-theme-border hidden sm:block" />

            <button 
              onClick={logout}
              className={cn(
                "p-1.5 md:p-2.5 border rounded-xl transition-all group shadow-sm",
                theme.isLight ? "bg-white hover:bg-gray-50 border-black/10" : "bg-theme-text/10 hover:bg-theme-text/20 border-theme-border"
              )}
              title="Logout"
            >
              <LogOut className={cn("w-3.5 md:w-5 h-3.5 md:h-5 transition-colors", theme.isLight ? "text-black" : "text-theme-subtext group-hover:text-theme-text")} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-6 py-8 md:py-12 space-y-8 md:space-y-12">
        {/* Navigation */}
        <nav className={cn(
          "flex gap-4 md:gap-8 border-b overflow-x-auto no-scrollbar whitespace-nowrap px-4 md:px-0 scroll-smooth",
          theme.isLight ? "border-black/20" : "border-theme-border"
        )}>
          <button 
            onClick={() => setActiveTab("overview")}
            className={cn(
              "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
              activeTab === "overview" 
                ? (theme.isLight ? "text-black" : "text-theme-text") 
                : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
            )}
          >
            Overview
            {activeTab === "overview" && (
              <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
            )}
          </button>
          
          {isAdmin && (
            <button 
              onClick={() => setActiveTab("admin")}
              className={cn(
                "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
                activeTab === "admin" 
                  ? (theme.isLight ? "text-black" : "text-theme-text") 
                  : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
              )}
            >
              Admin
              {activeTab === "admin" && (
                <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
              )}
            </button>
          )}
          <button 
            onClick={() => setActiveTab("compose")}
            className={cn(
              "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
              activeTab === "compose" 
                ? (theme.isLight ? "text-black" : "text-theme-text") 
                : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
            )}
          >
            Compose
            {activeTab === "compose" && (
              <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
            )}
          </button>
          <button 
            onClick={() => setActiveTab("history")}
            className={cn(
              "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
              activeTab === "history" 
                ? (theme.isLight ? "text-black" : "text-theme-text") 
                : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
            )}
          >
            History
            {activeTab === "history" && (
              <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
            )}
          </button>
          {isAdmin && (
            <button 
              onClick={() => setActiveTab("analytics")}
              className={cn(
                "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
                activeTab === "analytics" 
                  ? (theme.isLight ? "text-black" : "text-theme-text") 
                  : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
              )}
            >
              Analytics
              {activeTab === "analytics" && (
                <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
              )}
            </button>
          )}
          <button 
            onClick={() => setActiveTab("connections")}
            className={cn(
              "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative flex items-center gap-2 uppercase md:normal-case tracking-widest md:tracking-normal",
              activeTab === "connections" 
                ? (theme.isLight ? "text-black" : "text-theme-text") 
                : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
            )}
          >
            Connections
            {Object.keys(connections).length === 0 && (
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
            )}
            {activeTab === "connections" && (
              <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
            )}
          </button>
          {isAdmin && (
            <button 
              onClick={() => setActiveTab("settings")}
              className={cn(
                "pb-4 text-xs md:text-sm font-bold md:font-medium transition-all relative uppercase md:normal-case tracking-widest md:tracking-normal",
                activeTab === "settings" 
                  ? (theme.isLight ? "text-black" : "text-theme-text") 
                  : (theme.isLight ? "text-black/60 hover:text-black" : "text-theme-subtext hover:text-theme-text/60")
              )}
            >
              Settings
              {activeTab === "settings" && (
                <motion.div layoutId="nav" className={cn("absolute bottom-0 left-0 right-0 h-[2px]", theme.isLight ? "bg-black" : "bg-theme-text")} />
              )}
            </button>
          )}
        </nav>

        {/* Content */}
        <div className="min-h-[600px]">
          <AnimatePresence mode="wait">
            {activeTab === "overview" ? (
              <motion.div 
                key="overview"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <Overview user={user} credits={credits} connections={connections} theme={theme} onNavigate={setActiveTab} />
              </motion.div>
            ) : activeTab === "admin" && isAdmin ? (
              <motion.div 
                key="admin"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <AdminDashboard theme={theme} />
              </motion.div>
            ) : activeTab === "compose" ? (
              <motion.div 
                key="compose"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <PostComposer 
                  user={user} 
                  credits={credits} 
                  isPaid={isPaid} 
                  connections={connections} 
                  theme={theme} 
                  onNavigate={setActiveTab} 
                  isActive={isActive}
                />
              </motion.div>
            ) : activeTab === "history" ? (
              <motion.div 
                key="history"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <PostHistory user={user} theme={theme} />
              </motion.div>
            ) : activeTab === "analytics" ? (
              <motion.div 
                key="analytics"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <AnalyticsDashboard theme={theme} />
              </motion.div>
            ) : activeTab === "connections" ? (
              <motion.div 
                key="connections"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <ConnectionsManager connections={connections} theme={theme} />
              </motion.div>
            ) : (
              <motion.div 
                key="settings"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <SettingsView user={user} theme={theme} apiMode={apiMode} onRefreshStatus={refreshStatus} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Manage Credits Modal */}
      {isTopUpOpen && (
        <div className="fixed inset-0 bg-theme-bg/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={cn(
              "border border-theme-border p-6 md:p-8 rounded-3xl max-w-md w-full space-y-8 shadow-2xl",
              theme.isLight ? "bg-white" : "bg-theme-bg"
            )}
          >
            <div className="space-y-2 text-center">
              <h2 className="text-2xl font-display font-black text-theme-text uppercase tracking-tight">Manage Credits</h2>
              <p className="text-sm text-theme-subtext font-semibold">Adjust your broadcast balance using packs.</p>
            </div>

            <div className="space-y-6">
              {/* Pack Selection */}
              <div className="grid grid-cols-1 gap-4">
                {PACK_CONFIG.map((pack) => (
                  <div 
                    key={pack.id}
                    className="flex items-center justify-between p-4 bg-theme-text/5 border border-theme-border rounded-2xl"
                  >
                    <div className="flex flex-col">
                      <span className="text-xs font-black text-theme-text uppercase tracking-widest">{pack.label} Pack</span>
                      <span className="text-[10px] text-theme-subtext font-bold">${(pack.price / 100).toFixed(0)} for {pack.amount} Broadcasts</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => setPackSelections(prev => ({ ...prev, [pack.id]: prev[pack.id] - 1 }))}
                        className="w-8 h-8 rounded-full bg-theme-text/10 flex items-center justify-center hover:bg-theme-text/20 transition-colors"
                      >
                        <Minus className="w-4 h-4 text-theme-text" />
                      </button>
                      <span className="text-xs font-mono font-bold w-4 text-center">{packSelections[pack.id]}</span>
                      <button 
                        onClick={() => setPackSelections(prev => ({ ...prev, [pack.id]: prev[pack.id] + 1 }))}
                        className="w-8 h-8 rounded-full bg-theme-text/10 flex items-center justify-center hover:bg-theme-text/20 transition-colors"
                      >
                        <Plus className="w-4 h-4 text-theme-text" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="space-y-4">
                <div className={cn(
                  "p-6 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2",
                  pendingCredits > 0 ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-500" : 
                  pendingCredits < 0 ? "border-rose-500/30 bg-rose-500/5 text-rose-500" : 
                  "border-theme-border bg-theme-text/5 text-theme-text"
                )}>
                  <div className="text-[10px] text-theme-subtext uppercase tracking-[0.2em] font-black">Adjustment Summary</div>
                  <div className="text-3xl font-mono font-bold tracking-tighter">
                    {pendingCredits > 0 ? "+" : ""}{pendingCredits} Broadcasts
                  </div>
                  <div className="text-[11px] font-bold text-theme-subtext">
                    {pendingCost >= 0 ? "Total Cost" : "Refund Amount"}: ${Math.abs(pendingCost / 100).toFixed(2)}
                  </div>
                </div>

                {/* Balance Preview */}
                {pendingCredits !== 0 && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-theme-text/5 border border-theme-border rounded-xl">
                      <div className="text-[8px] text-theme-subtext uppercase font-black tracking-widest">Current</div>
                      <div className="text-sm font-mono font-bold text-theme-text">${(credits / 100).toFixed(2)}</div>
                    </div>
                    <div className={cn(
                      "p-3 border rounded-xl relative overflow-hidden",
                      pendingCredits > 0 ? "bg-emerald-500/10 border-emerald-500/30" : "bg-rose-500/10 border-rose-500/30"
                    )}>
                      <div className="text-[8px] text-theme-subtext uppercase font-black tracking-widest">New Balance</div>
                      <div className="text-sm font-mono font-bold text-theme-text">
                        ${Math.max(0, (credits + (pendingCredits * 10)) / 100).toFixed(2)}
                      </div>
                      <ArrowUpRight className={cn(
                        "absolute -top-1 -right-1 w-6 h-6 opacity-10",
                        pendingCredits > 0 ? "text-emerald-500 rotate-0" : "text-rose-500 rotate-90"
                      )} />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-3">
                <button 
                  disabled={pendingCredits === 0}
                  onClick={async () => {
                    try {
                      if (pendingCredits > 0) {
                        await replenishCreditsSecurely(pendingCredits); 
                      } else if (pendingCredits < 0) {
                        // For demo, we'll just allow top-ups for now or implement secure subtract later
                        alert("Secure subtraction not implemented yet in demo");
                      }
                      setPackSelections({ small: 0, medium: 0, large: 0 });
                      setIsTopUpOpen(false);
                    } catch (err: any) {
                      alert(`Transaction failed: ${err.message}`);
                    }
                  }}
                  className={cn(
                    "w-full py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-lg",
                    pendingCredits === 0 
                      ? "bg-theme-text/10 text-theme-text/30 cursor-not-allowed" 
                      : pendingCredits > 0 
                        ? "bg-theme-text text-theme-bg hover:opacity-90"
                        : "bg-rose-500 text-white hover:bg-rose-600"
                  )}
                >
                  {pendingCredits > 0 ? `Complete Purchase ($${(pendingCost / 100).toFixed(2)})` : 
                   pendingCredits < 0 ? `Confirm Deduction` : "Select a Pack"}
                </button>
                <p className="text-[10px] text-center text-theme-subtext font-medium leading-relaxed mt-2 uppercase tracking-tighter">
                  Non-refundable • Instant balance refresh
                </p>
                <button 
                  onClick={() => {
                    setPackSelections({ small: 0, medium: 0, large: 0 });
                    setIsTopUpOpen(false);
                  }}
                  className="w-full py-2 text-xs text-theme-text/60 hover:text-theme-text font-bold transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
      <Footer theme={theme} onUtilityClick={onUtilityClick} />
    </div>
  );
}

function Footer({ theme, onUtilityClick }: { theme: any, onUtilityClick: (type: any) => void }) {
  return (
    <footer className="py-12 border-t border-theme-border mt-12 w-full max-w-md mx-auto">
      <div className="flex flex-col items-center gap-6">
        <div className="flex items-center gap-8">
            <a 
              href="https://twitter.com/syphn" 
              target="_blank" 
              rel="noopener noreferrer"
              className={cn(
                "p-3 bg-theme-text/5 hover:bg-sky-500/10 border border-transparent hover:border-sky-500/20 rounded-xl transition-all group",
                theme.isLight ? "text-black hover:text-sky-600" : "text-theme-text/60 hover:text-sky-400"
              )}
              title="Follow us on Twitter"
            >
              <Twitter className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </a>
            <a 
              href="https://facebook.com/syphn" 
              target="_blank" 
              rel="noopener noreferrer"
              className={cn(
                "p-3 bg-theme-text/5 hover:bg-blue-600/10 border border-transparent hover:border-blue-600/20 rounded-xl transition-all group",
                theme.isLight ? "text-black hover:text-blue-700" : "text-theme-text/60 hover:text-blue-600"
              )}
              title="Follow us on Facebook"
            >
              <Facebook className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </a>
            <a 
              href="https://instagram.com/syphn" 
              target="_blank" 
              rel="noopener noreferrer"
              className={cn(
                "p-3 bg-theme-text/5 hover:bg-pink-500/10 border border-transparent hover:border-pink-500/20 rounded-xl transition-all group",
                theme.isLight ? "text-black hover:text-pink-600" : "text-theme-text/60 hover:text-pink-500"
              )}
              title="Follow us on Instagram"
            >
              <Instagram className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </a>
        </div>
        <div className="flex items-center gap-2">
          <span className={cn(
            "text-[10px] uppercase tracking-[0.2em] font-black",
            theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]"
          )}>
            © 2026
          </span>
          <img 
            src="https://i.imgur.com/nAOlGZm.png" 
            alt="Syphn Logo" 
            className={cn(
              "h-3 w-auto object-contain",
              !theme.isLight && "brightness-0 invert"
            )}
            referrerPolicy="no-referrer"
          />
          <span className={cn(
            "text-[10px] uppercase tracking-[0.2em] font-black",
            theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]"
          )}>
            . All rights reserved.
          </span>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            {["Terms", "Privacy", "Refunds", "Status"].map((link) => (
              <button 
                key={link}
                onClick={() => onUtilityClick(link)}
                className="text-[9px] uppercase tracking-widest font-black text-theme-subtext hover:text-theme-primary transition-colors"
              >
                {link}
              </button>
            ))}
        </div>
      </div>
    </footer>
  );
}

function CalendarView({ selectedDate, onSelect, theme }: { selectedDate: string, onSelect: (date: string) => void, theme: any }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth)
  });

  const startDay = getDay(daysInMonth[0]);
  const blanks = Array(startDay).fill(null);
  const allDays = [...blanks, ...daysInMonth];

  const handlePrevMonth = () => setCurrentMonth(addDays(startOfMonth(currentMonth), -1));
  const handleNextMonth = () => setCurrentMonth(addDays(endOfMonth(currentMonth), 1));
  const handleGoToToday = () => {
    const today = new Date();
    setCurrentMonth(today);
    onSelect(format(today, "yyyy-MM-dd'T'HH:mm"));
  };

  const isSelected = (day: Date) => {
    if (!selectedDate) return false;
    return isSameDay(day, new Date(selectedDate));
  };

  return (
    <div className={cn(
      "p-5 border border-theme-border rounded-2xl space-y-5 shadow-xl transition-all",
      theme.isLight ? "bg-white" : "bg-theme-bg"
    )}>
      <div className="flex items-center justify-between pb-2 border-b border-theme-border/50">
        <div className="space-y-0.5">
          <h4 className="text-[11px] font-black uppercase tracking-widest text-theme-text">
            {format(currentMonth, 'MMMM')}
          </h4>
          <p className="text-[9px] font-mono font-bold text-theme-subtext">
            {format(currentMonth, 'yyyy')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={handleGoToToday}
            className="px-2 py-1 bg-theme-text/5 hover:bg-theme-text/10 text-[8px] font-black uppercase tracking-widest text-theme-subtext hover:text-theme-text rounded-md transition-all"
          >
            Today
          </button>
          <div className="flex gap-1">
            <button onClick={handlePrevMonth} className="p-1.5 hover:bg-theme-text/10 rounded-lg text-theme-subtext hover:text-theme-text transition-colors">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button onClick={handleNextMonth} className="p-1.5 hover:bg-theme-text/10 rounded-lg text-theme-subtext hover:text-theme-text transition-colors">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1">
        {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => (
          <div key={d} className="text-[9px] font-black text-theme-subtext/40 text-center py-2 uppercase tracking-tighter">{d}</div>
        ))}
        {allDays.map((day, i) => (
          <div key={i} className="aspect-square flex items-center justify-center p-0.5">
            {day ? (
              <button
                disabled={isPast(day) && !isToday(day)}
                onClick={() => {
                  const current = selectedDate ? new Date(selectedDate) : new Date();
                  const newDate = setMinutes(setHours(day, current.getHours()), current.getMinutes());
                  onSelect(format(newDate, "yyyy-MM-dd'T'HH:mm"));
                }}
                className={cn(
                  "w-full h-full rounded-xl text-[10px] font-bold transition-all flex items-center justify-center relative group",
                  isSelected(day) 
                    ? "bg-theme-text text-theme-bg shadow-md scale-95" 
                    : isToday(day)
                      ? "text-theme-text border-2 border-theme-text/20 hover:border-theme-text/40"
                      : "text-theme-subtext hover:bg-theme-text/10 hover:text-theme-text",
                  isPast(day) && !isToday(day) && "opacity-20 cursor-not-allowed"
                )}
              >
                {format(day, 'd')}
                {isToday(day) && !isSelected(day) && (
                  <div className="absolute bottom-1 w-1 h-1 rounded-full bg-theme-text" />
                )}
              </button>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}

function PostComposer({ user, credits, isPaid, connections, theme, onNavigate, isActive }: { user: any, credits: number, isPaid: boolean, connections: any, theme: any, onNavigate: (tab: any) => void, isActive: boolean }) {
  const [content, setContent] = useState("");
  const [selectedChannels, setSelectedChannels] = useState<Array<{ platformId: string, accountId: string }>>([]);
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledDate, setScheduledDate] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [mediaFile, setMediaFile] = useState<{ file: File, url: string, type: 'image' | 'video' } | null>(null);
  const [needsReconnect, setNeedsReconnect] = useState(false);
  const [message, setMessage] = useState<{ 
    type: "success" | "error" | "warning", 
    text: string,
    nextSteps?: string[]
  } | null>(null);

  useEffect(() => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // If there are no connections, there's nothing to reconnect
    if (!connections || Object.keys(connections).length === 0) {
      setNeedsReconnect(false);
      return;
    }

    // Check if any connection was made within the last 30 days
    let hasRecentConnection = false;
    Object.values(connections).forEach((platformAccounts: any) => {
      const accounts = Array.isArray(platformAccounts) ? platformAccounts : platformAccounts ? [platformAccounts] : [];
      accounts.forEach((acc: any) => {
        if (acc.connectedAt) {
          const connectedDate = new Date(acc.connectedAt);
          if (connectedDate >= thirtyDaysAgo) {
            hasRecentConnection = true;
          }
        }
      });
    });

    // If they just connected something recently, we don't need to force reconnect
    if (hasRecentConnection) {
      setNeedsReconnect(false);
      return;
    }

    // Otherwise check their last post activity
    const checkLastPost = async () => {
      try {
        const q = query(
          collection(db, "posts"),
          where("uid", "==", user.uid),
          orderBy("createdAt", "desc"),
          limit(1)
        );
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          const lastPost = snapshot.docs[0].data();
          if (lastPost.createdAt) {
            const lastPostDate = lastPost.createdAt.toDate();
            if (lastPostDate < thirtyDaysAgo) {
              setNeedsReconnect(true); // Last post was > 30 days ago
            } else {
              setNeedsReconnect(false); // They posted recently
            }
          }
        } else {
          // They have old connections (>30 days) and NO posts ever. So it's expired.
          setNeedsReconnect(true);
        }
      } catch (err) {
        console.error("Error checking last post:", err);
      }
    };
    checkLastPost();
  }, [user.uid, connections]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const togglePlatform = (id: string) => {
    const platform = PLATFORMS.find(p => p.id === id);
    if (!platform) return;

    const platformAccounts = Array.isArray(connections[id]) 
      ? connections[id] 
      : connections[id] ? [{ ...connections[id], id: 'legacy' }] : [];

    if (platformAccounts.length === 0) {
      setMessage({
        type: "error",
        text: `You must connect your ${platform.name} account first.`,
        nextSteps: ["Go to the Connections tab to link your accounts."]
      });
      return;
    }

    const allPlatformChannels = platformAccounts.map((acc: any) => ({ platformId: id, accountId: acc.id }));
    const alreadySelectedCount = selectedChannels.filter(c => c.platformId === id).length;

    if (alreadySelectedCount === platformAccounts.length) {
      // Remove all for this platform
      setSelectedChannels(prev => prev.filter(c => c.platformId !== id));
    } else {
      // Add all missing ones
      setSelectedChannels(prev => {
        const others = prev.filter(c => c.platformId !== id);
        return [...others, ...allPlatformChannels];
      });
    }
  };

  const removeChannel = (platformId: string, accountId: string) => {
    setSelectedChannels(prev => prev.filter(c => !(c.platformId === platformId && c.accountId === accountId)));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const type = file.type.startsWith('video/') ? 'video' : 'image';

    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      toast.error("Unsupported file type. Please upload an image or video.");
      return;
    }

    // Size validation
    if (type === 'image' && file.size > 5 * 1024 * 1024) {
      toast.error("Image size must be less than 5MB");
      return;
    }
    if (type === 'video' && file.size > 50 * 1024 * 1024) {
      toast.error("Video size must be less than 50MB");
      return;
    }

    if (mediaFile) {
      URL.revokeObjectURL(mediaFile.url);
    }

    let processedFile = file;

    // Apply watermark to images for free users
    if (!isPaid && type === 'image') {
      try {
        processedFile = await addWatermarkToImage(file);
      } catch (err) {
        console.error("Watermarking failed:", err);
        // Fallback to original file if watermarking fails
      }
    }

    const url = URL.createObjectURL(processedFile);
    setMediaFile({ file: processedFile, url, type });
  };

  const removeMedia = () => {
    if (mediaFile) {
      URL.revokeObjectURL(mediaFile.url);
      setMediaFile(null);
    }
  };

  const handleSend = async () => {
    if (!content || selectedChannels.length === 0) return;
    
    setIsSending(true);
    setMessage(null);

    try {
      const scheduledAt = isScheduling && scheduledDate ? new Date(scheduledDate) : null;
      
      if (scheduledAt && scheduledAt <= new Date()) {
        throw new Error("Scheduled time must be in the future");
      }

      await uploadPost({ 
        content, 
        channels: selectedChannels,
        scheduledAt,
        media: mediaFile ? { type: mediaFile.type, name: mediaFile.file.name } : null
      });

      setMessage({ 
        type: "success", 
        text: scheduledAt ? "Post scheduled successfully!" : "Post broadcasted successfully!" 
      });
      setContent("");
      setSelectedChannels([]);
      setIsScheduling(false);
      setScheduledDate("");
      setMediaFile(null);
    } catch (err: any) {
      const errorText = err.message || "An unexpected error occurred while broadcasting.";
      let nextSteps: string[] = ["Please try again in a few moments."];

      const lowerError = errorText.toLowerCase();

      if (lowerError.includes("future")) {
        nextSteps = [
          "Adjust the scheduled date and time to a point in the future.",
          "Ensure your device's clock is synchronized correctly."
        ];
      } else if (lowerError.includes("credits") || lowerError.includes("insufficient")) {
        nextSteps = [
          "Top up your account with more credits in the dashboard.",
          "Try selecting fewer platforms to reduce the cost.",
          "Wait for your next monthly credit allowance if you are on a subscription."
        ];
      } else if (lowerError.includes("unreachable") || lowerError.includes("syphn.app")) {
        nextSteps = [
          "Wait for the syphn.app domain and hosting to go live.",
          "Remove your Syphn API key from the Secrets menu to use Demo Mode instead.",
          "Check your internet connection and try again."
        ];
      } else if (lowerError.includes("api") || lowerError.includes("key")) {
        nextSteps = [
          "Verify that your Syphn API key is correctly configured in the settings.",
          "Ensure the key has the necessary permissions for all selected platforms.",
          "Check the Syphn status page for any ongoing service interruptions."
        ];
      } else if (lowerError.includes("content") || lowerError.includes("limit") || lowerError.includes("length")) {
        nextSteps = [
          "Review the platform-specific character limits shown in the composer.",
          "Shorten your post content to meet the requirements of all selected platforms.",
          "Remove heavy links or media descriptions that might be padding the count."
        ];
      } else if (lowerError.includes("media") || lowerError.includes("file") || lowerError.includes("size")) {
        nextSteps = [
          "Ensure your media file is within the size limits (e.g., 5MB for images, 50MB for videos).",
          "Try using a common format like JPG, PNG, or MP4.",
          "If watermarking failed, try uploading a slightly smaller resolution image."
        ];
      } else if (lowerError.includes("connection") || lowerError.includes("disconnected") || lowerError.includes("reconnect")) {
        nextSteps = [
          "Go to the Connections tab and re-link your social media accounts.",
          "Ensure the target account hasn't changed its password or permissions.",
          "Verify that your account isn't temporarily locked by the platform."
        ];
      } else if (lowerError.includes("rate limit") || lowerError.includes("too many requests")) {
        nextSteps = [
          "Slow down your broadcasting frequency; you've hit a platform safety limit.",
          "Wait 15-30 minutes before attempting to post to those platforms again.",
          "Spread your posts out across different times using the scheduler."
        ];
      } else if (lowerError.includes("auth") || lowerError.includes("permission") || lowerError.includes("denied")) {
        nextSteps = [
          "Sign out and sign back in to refresh your Syphn session.",
          "Check if your Syphn account has any restrictions or flags.",
          "Ensure all platform permissions were accepted during the connection process."
        ];
      }

      setMessage({ 
        type: "error", 
        text: errorText,
        nextSteps 
      });
    } finally {
      setIsSending(false);
    }
  };

  const isOverLimit = selectedChannels.some(c => {
    const platform = PLATFORMS.find(p => p.id === c.platformId);
    return platform && content.length > platform.limit;
  });
  const totalCost = selectedChannels.length * 10;
  const isAdmin = user?.email?.toLowerCase() === 'ghozt.app@gmail.com';
  const canSend = content.length > 0 && selectedChannels.length > 0 && (isAdmin || (isActive && credits >= totalCost)) && !isOverLimit;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12">
      <div className="lg:col-span-2 space-y-6 md:space-y-8">
        {needsReconnect && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-2xl border border-amber-500/20 bg-amber-500/5 flex flex-col md:flex-row items-center justify-between gap-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                <RefreshCw className="w-5 h-5 text-amber-500 animate-spin-[3s_linear_infinite]" />
              </div>
              <div>
                <p className="text-sm font-bold text-theme-text">Reconnect Your Accounts</p>
                <p className="text-xs text-theme-subtext">Your social media connection may have expired after 30 days of inactivity. Reconnect your accounts to ensure smooth broadcasting.</p>
              </div>
            </div>
            <button 
              onClick={() => onNavigate("connections")}
              className="px-4 py-2 bg-amber-500 text-white text-xs font-black uppercase tracking-widest rounded-xl hover:bg-amber-600 transition-colors shadow-lg shadow-amber-500/20 whitespace-nowrap"
            >
              Reconnect Now
            </button>
          </motion.div>
        )}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className={cn(
              "text-[9px] md:text-[10px] uppercase tracking-[0.2em] font-black",
              theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]"
            )}>Content</label>
            <button 
              onClick={() => setContent("🚀 Just launched my new project! Check out the latest updates on our dashboard. #innovation #tech #launch")}
              className={cn(
                "text-[8px] md:text-[9px] font-black uppercase tracking-widest transition-colors",
                theme.isLight ? "text-black hover:text-black/80" : "text-theme-subtext hover:text-theme-text"
              )}
            >
              Sample
            </button>
          </div>
          <div className="relative">
            <textarea 
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What's on your mind?"
              className={cn(
                "w-full h-48 md:h-64 border rounded-2xl p-4 md:p-6 focus:outline-none transition-all resize-none text-base md:text-lg leading-relaxed shadow-sm",
                theme.isLight 
                  ? "bg-white text-black border-black/10 focus:border-black/30 placeholder:text-black/30" 
                  : "bg-theme-bg text-theme-text border-theme-border focus:border-theme-text/20 placeholder:text-theme-subtext/50"
              )}
            />
            {!isPaid && (
              <div className="absolute bottom-4 right-6 pointer-events-none select-none">
                <motion.div 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 px-3 py-1.5 bg-theme-text/5 border border-theme-border/50 rounded-xl backdrop-blur-sm"
                >
                  <span className={cn(
                    "text-[10px] font-black uppercase tracking-widest",
                    theme.isLight ? "text-theme-text/40" : "text-theme-subtext opacity-40"
                  )}>
                    + Sent via Syphn
                  </span>
                </motion.div>
              </div>
            )}
          </div>

          {/* Unified Character Limits per unique platform type */}
          {Array.from(new Set(selectedChannels.map(c => c.platformId))).length > 0 && (
            <div className="flex flex-wrap gap-4 pt-2">
              {Array.from(new Set(selectedChannels.map(c => c.platformId))).map(platformId => {
                const platform = PLATFORMS.find(p => p.id === platformId);
                if (!platform) return null;
                
                const watermarkLength = isPaid ? 0 : 17; // "\n\nSent via Syphn"
                const effectiveLength = content.length + watermarkLength;
                const remaining = platform.limit - effectiveLength;
                const percentage = Math.min((effectiveLength / platform.limit) * 100, 100);
                const isNearing = remaining <= platform.limit * 0.1 && remaining >= 0;
                const isExceeded = remaining < 0;

                return (
                  <div key={platformId} className="flex flex-col gap-1.5 min-w-[120px]">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <platform.icon className={cn("w-3 h-3", isExceeded ? "text-red-500" : isNearing ? "text-amber-400" : platform.color)} />
                        <span className="text-[9px] font-black uppercase tracking-wider text-theme-text">{platform.name}</span>
                      </div>
                      <span className={cn(
                        "text-[9px] font-mono",
                        isExceeded ? "text-red-500 font-black" : isNearing ? "text-amber-400 font-bold" : "text-theme-text"
                      )}>
                        {remaining} left
                      </span>
                    </div>
                    <div className={cn(
                      "h-1 rounded-full overflow-hidden",
                      theme.isLight ? "bg-theme-text/10" : "bg-theme-bg-accent"
                    )}>
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${percentage}%` }}
                        className={cn(
                          "h-full rounded-full transition-colors duration-300",
                          isExceeded ? "bg-red-500" : isNearing ? "bg-amber-400" : "bg-theme-text/20"
                        )}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Media Preview */}
          <AnimatePresence>
            {mediaFile && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 10 }}
                className="relative mt-6 rounded-3xl overflow-hidden border border-theme-border bg-theme-bg group"
              >
                <div className="absolute top-4 left-4 z-10 px-3 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-white/10 flex items-center gap-2">
                  {mediaFile.type === 'image' ? <ImageIcon className="w-3 h-3 text-white/60" /> : <Film className="w-3 h-3 text-white/60" />}
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">{mediaFile.type} Preview • {(mediaFile.file.size / (1024 * 1024)).toFixed(1)}MB</span>
                </div>

                <button 
                  onClick={removeMedia}
                  className="absolute top-4 right-4 z-10 p-2.5 bg-red-500/80 hover:bg-red-500 text-white rounded-full backdrop-blur-md transition-all shadow-lg hover:scale-110 active:scale-95 flex items-center justify-center"
                  title="Remove Media"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="w-full flex items-center justify-center bg-black/40 min-h-[200px]">
                  {mediaFile.type === 'image' ? (
                    <img src={mediaFile.url} alt="Upload preview" className="w-full h-auto max-h-[500px] object-contain" />
                  ) : (
                    <video src={mediaFile.url} controls className="w-full h-auto max-h-[500px]" />
                  )}
                  {!isPaid && (
                    <div className="absolute bottom-6 right-8 px-3 py-1.5 bg-black/50 backdrop-blur-md rounded-xl flex items-center gap-2 pointer-events-none select-none border border-white/10 shadow-lg">
                      <span className="text-[10px] font-black uppercase tracking-widest text-white/90">Sent via</span>
                      <img 
                        src="https://i.imgur.com/nAOlGZm.png" 
                        alt="Syphn Logo" 
                        className="h-3 w-auto object-contain brightness-0 invert"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*,video/*"
                className="hidden"
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className={cn(
                  "relative group px-6 py-3 rounded-full font-black uppercase tracking-[0.2em] text-[9px] transition-all duration-500 flex items-center gap-3 overflow-hidden",
                  mediaFile 
                    ? "bg-theme-bg border border-theme-border text-theme-text hover:border-theme-text/40"
                    : "bg-theme-text text-theme-bg hover:pr-8"
                )}
              >
                <div className="relative z-10 flex items-center gap-3">
                  {mediaFile ? (
                    <ImageIcon className="w-3.5 h-3.5 transition-transform duration-500 group-hover:scale-110" />
                  ) : (
                    <Plus className="w-3.5 h-3.5 transition-transform duration-500 group-hover:rotate-90" />
                  )}
                  <span>{mediaFile ? "Change Media" : "Add Media"}</span>
                </div>
                
                {!mediaFile && (
                  <div className="absolute right-4 opacity-0 -translate-x-2 transition-all duration-500 group-hover:opacity-100 group-hover:translate-x-0">
                    <ChevronRight className="w-3 h-3" />
                  </div>
                )}
                
                {/* Animated background for empty state */}
                {!mediaFile && (
                  <div className="absolute inset-0 bg-gradient-to-r from-theme-text via-theme-text/90 to-theme-text opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                )}
              </button>
            </div>
            <div className="flex flex-col items-end gap-1">
              <div className={cn(
                "text-[9px] font-medium text-theme-subtext uppercase tracking-widest",
              )}>
                Max: 5MB Image / 50MB Video
              </div>
              <div className={cn(
                "text-[10px] uppercase font-mono font-bold",
                theme.isLight ? "text-black" : "text-theme-text"
              )}>
                {content.length + (isPaid ? 0 : 17)} Characters
              </div>
              <div className="flex flex-wrap justify-end gap-x-4 gap-y-1 max-w-[300px]">
                {/* Unified Character Limits per unique platform type */}
                {Array.from(new Set(selectedChannels.map(c => c.platformId))).map(platformId => {
                  const platform = PLATFORMS.find(p => p.id === platformId);
                  if (!platform) return null;
                  const watermarkLength = isPaid ? 0 : 17;
                  const remaining = platform.limit - (content.length + watermarkLength);
                  const isOver = remaining < 0;
                  return (
                    <div key={platformId} className="flex items-center gap-1.5">
                      <platform.icon className={cn("w-2.5 h-2.5", isOver ? "text-red-500" : theme.isLight ? "text-black" : "text-theme-text/60")} />
                      <span className={cn(
                        "text-[9px] font-mono uppercase tracking-tighter",
                        isOver ? "text-red-500 font-bold" : theme.isLight ? "text-black" : "text-theme-subtext"
                      )}>
                        {remaining}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className={cn(
              "text-[10px] uppercase tracking-[0.2em] font-black",
              theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]"
            )}>Target Platforms</label>
            <div className="flex gap-2">
              <AnimatePresence>
                {Array.from(new Set(selectedChannels.map(c => c.platformId))).map(platformId => {
                  const platform = PLATFORMS.find(p => p.id === platformId);
                  if (!platform) return null;
                  return (
                    <motion.div
                      key={platformId}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0, opacity: 0 }}
                    >
                      <platform.icon className={cn("w-3 h-3", platform.color)} />
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
            {PLATFORMS.map((platform) => {
              const Icon = platform.icon;
              const isSelected = selectedChannels.some(c => c.platformId === platform.id);
              const isConnected = !!connections[platform.id];
              const watermarkLength = isPaid ? 0 : 17;
              const effectiveLength = content.length + watermarkLength;
              const isOver = effectiveLength > platform.limit;
              const remaining = platform.limit - effectiveLength;
              
              return (
                <motion.button
                  key={platform.id}
                  whileHover={{ scale: isConnected ? 1.02 : 1 }}
                  whileTap={{ scale: isConnected ? 0.98 : 1 }}
                  onClick={() => togglePlatform(platform.id)}
                  className={cn(
                    "p-3 rounded-2xl border transition-all flex items-center gap-3 relative overflow-hidden group shadow-sm",
                    isSelected 
                      ? isOver 
                        ? "bg-red-500/10 border-red-500/40 ring-1 ring-red-500/20" 
                        : theme.isLight 
                          ? "bg-white border-black ring-2 ring-black/5" 
                          : `bg-${platform.brand}/10 border-${platform.brand}/60 ring-2 ring-${platform.brand}/20` 
                      : isConnected
                        ? theme.isLight
                          ? "bg-white border-black/10 hover:border-black/30 hover:bg-gray-50"
                          : "bg-theme-bg/60 border-theme-border hover:border-theme-text/30 hover:bg-theme-bg-accent/40"
                        : "opacity-40 grayscale cursor-not-allowed border-dashed border-theme-border"
                  )}
                >
                  {/* Selection Glow */}
                  {isSelected && !isOver && !theme.isLight && (
                    <motion.div 
                      layoutId={`glow-${platform.id}`}
                      className={cn("absolute inset-0 blur-xl pointer-events-none opacity-40", `bg-${platform.brand}/20`)}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    />
                  )}

                  <div className="relative shrink-0">
                    {isConnected && !isSelected && (
                      <div className="w-2 h-2 bg-emerald-500 rounded-full border border-theme-bg shadow-[0_0_8px_rgba(16,185,129,0.5)] mr-1" />
                    )}
                  </div>

                   <div className="flex flex-col items-start min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <Icon className={cn(
                        "w-3 h-3",
                        isSelected 
                          ? (isOver ? "text-red-500" : platform.color) 
                          : isConnected
                            ? theme.isLight ? "text-black/70" : "text-theme-text/70"
                            : "text-theme-text/20"
                      )} />
                      <span className={cn(
                        "text-[10px] font-black uppercase tracking-widest truncate", 
                        isSelected 
                          ? (isOver ? "text-red-500" : theme.isLight ? "text-black" : "text-theme-text")
                          : isConnected
                            ? theme.isLight ? "text-black" : "text-theme-text/80"
                            : "text-theme-subtext"
                      )}>
                        {platform.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className={cn(
                        "text-[8px] font-mono",
                        isSelected 
                          ? isOver ? "text-red-500 font-black" : theme.isLight ? "text-black/60" : "text-theme-subtext"
                          : isConnected ? "text-theme-subtext/60" : "text-theme-subtext/40"
                      )}>
                        {isSelected ? `${remaining} left` : `${platform.limit} limit`}
                      </span>
                      {isOver && isSelected && (
                        <AlertCircle className="w-2.5 h-2.5 text-red-500 animate-pulse" />
                      )}
                    </div>
                  </div>

                  {/* Connected Hover Effect */}
                  {isConnected && !isSelected && (
                    <div className="absolute inset-0 bg-gradient-to-tr from-theme-text/[0.03] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className={cn(
              "text-[10px] uppercase tracking-[0.2em] font-black",
              theme.isLight ? "text-black" : "text-theme-text [text-shadow:var(--text-shadow-theme)]"
            )}>Scheduling</label>
            <button 
              onClick={() => setIsScheduling(!isScheduling)}
              className={cn(
                "text-[10px] font-bold uppercase tracking-widest transition-colors",
                isScheduling 
                  ? "text-theme-text" 
                  : theme.isLight ? "text-black hover:text-black/80" : "text-theme-subtext hover:text-theme-text"
              )}
            >
              {isScheduling ? "Cancel Scheduling" : "Schedule for later"}
            </button>
          </div>
          
          <AnimatePresence>
            {isScheduling && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <CalendarView 
                    selectedDate={scheduledDate} 
                    onSelect={setScheduledDate} 
                    theme={theme} 
                  />
                  
                  <div className="space-y-4">
                    <div className="p-5 bg-theme-bg border border-theme-border rounded-[2rem] space-y-6 shadow-xl relative overflow-hidden">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] text-theme-text uppercase tracking-widest font-black">Time Selection</label>
                          {scheduledDate && (
                            <button 
                              onClick={() => setScheduledDate("")}
                              className="text-[9px] font-bold text-red-500 uppercase tracking-widest hover:underline"
                            >
                              Clear
                            </button>
                          )}
                        </div>
                        <div className={cn(
                          "flex items-center gap-4 p-4 rounded-2xl border transition-all shadow-sm group",
                          theme.isLight 
                            ? "bg-white border-black/10 focus-within:border-black/30" 
                            : "bg-theme-bg border-theme-border focus-within:border-theme-text/30"
                        )}>
                          <div className="p-2 bg-theme-text/5 rounded-lg">
                            <Clock className="w-4 h-4 text-theme-text/60" />
                          </div>
                          <input 
                            type="time"
                            value={scheduledDate ? format(new Date(scheduledDate), "HH:mm") : ""}
                            onChange={(e) => {
                              const [hours, minutes] = e.target.value.split(':');
                              const current = scheduledDate ? new Date(scheduledDate) : new Date();
                              const newDate = setMinutes(setHours(current, parseInt(hours)), parseInt(minutes));
                              setScheduledDate(format(newDate, "yyyy-MM-dd'T'HH:mm"));
                            }}
                            className={cn(
                              "bg-transparent border-none focus:outline-none text-base text-theme-text font-bold w-full",
                              theme.isLight ? "[color-scheme:light]" : "[color-scheme:dark]"
                            )}
                          />
                        </div>
                      </div>

                        <div className="space-y-3">
                          <label className="text-[10px] text-theme-text uppercase tracking-widest font-black">Quick Presets</label>
                          <div className="grid grid-cols-2 gap-3">
                            {[
                              { label: "In 1 Hour", icon: Zap, date: addHours(startOfHour(addHours(new Date(), 1)), 0) },
                              { label: "Tonight 8PM", icon: Clock, date: setMinutes(setHours(new Date(), 20), 0) },
                              { label: "Tomorrow 9AM", icon: Calendar, date: setMinutes(setHours(startOfTomorrow(), 9), 0) },
                              { label: "Tomorrow 6PM", icon: Clock, date: setMinutes(setHours(startOfTomorrow(), 18), 0) },
                              { label: "Next Monday", icon: Calendar, date: setMinutes(setHours(nextMonday(new Date()), 9), 0) },
                              { label: "Next Week", icon: Activity, date: addWeeks(new Date(), 1) },
                            ].map((preset) => (
                              <button
                                key={preset.label}
                                onClick={() => setScheduledDate(format(preset.date, "yyyy-MM-dd'T'HH:mm"))}
                                className={cn(
                                  "px-4 py-3 border rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-left flex items-center justify-between group relative overflow-hidden",
                                  theme.isLight 
                                    ? "bg-white border-black/10 hover:border-black/30 text-black/60 hover:text-black" 
                                    : "bg-theme-bg border-theme-border hover:border-theme-text/30 text-theme-subtext hover:text-theme-text"
                                )}
                              >
                                <div className="flex items-center gap-2 relative z-10">
                                  <preset.icon className="w-3 h-3 opacity-40 group-hover:opacity-100 transition-opacity" />
                                  {preset.label}
                                </div>
                                <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-40 group-hover:translate-y-0 group-hover:translate-x-0 transition-all relative z-10" />
                                <div className="absolute inset-0 bg-theme-text/[0.02] opacity-0 group-hover:opacity-100 transition-opacity" />
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                    {scheduledDate && (
                      <div className="p-4 bg-theme-text/5 border border-theme-text/10 rounded-2xl flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-[8px] text-theme-subtext uppercase font-bold tracking-widest">Scheduled for</p>
                          <p className="text-xs font-black text-theme-text">
                            {format(new Date(scheduledDate), "EEEE, MMM do 'at' h:mm a")}
                          </p>
                        </div>
                        <button 
                          onClick={() => setScheduledDate("")}
                          className="p-2 hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="space-y-8">
        <div className="p-6 md:p-8 bg-theme-bg border border-theme-border rounded-2xl space-y-6 md:space-y-8 lg:sticky lg:top-12 shadow-xl">
          <div className="space-y-4">
            <h3 className="text-[11px] md:text-sm font-display font-black uppercase tracking-widest">Broadcast Summary</h3>
            <div className="space-y-3">
              {!isAdmin && (
                <div className="flex justify-between text-sm">
                  <span className="text-theme-subtext">Cost per Platform</span>
                  <span className="font-mono">$0.10</span>
                </div>
              )}
              <div className="flex justify-between items-center text-sm">
                <span className="text-theme-text font-bold [text-shadow:var(--text-shadow-theme)]">Channels</span>
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-1">
                    {Array.from(new Set(selectedChannels.map(c => c.platformId))).slice(0, 4).map(platformId => {
                      const platform = PLATFORMS.find(p => p.id === platformId);
                      if (!platform) return null;
                      return (
                        <div key={platformId} className="w-5 h-5 rounded-full bg-theme-bg-accent border border-theme-border flex items-center justify-center backdrop-blur-sm">
                          <platform.icon className={cn("w-2.5 h-2.5", platform.color)} />
                        </div>
                      );
                    })}
                    {Array.from(new Set(selectedChannels.map(c => c.platformId))).length > 4 && (
                      <div className="w-5 h-5 rounded-full bg-theme-bg-accent border border-theme-border flex items-center justify-center backdrop-blur-sm text-[8px] font-bold">
                        +{Array.from(new Set(selectedChannels.map(c => c.platformId))).length - 4}
                      </div>
                    )}
                  </div>
                  <span className="font-mono text-xs ml-1">x{selectedChannels.length}</span>
                </div>
              </div>
              {selectedChannels.length > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-theme-text font-bold [text-shadow:var(--text-shadow-theme)]">Character Limit</span>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const platformIds = Array.from(new Set(selectedChannels.map(c => c.platformId)));
                      const mostRestrictive = platformIds.reduce((prev, curr) => {
                        const p1 = PLATFORMS.find(p => p.id === prev);
                        const p2 = PLATFORMS.find(p => p.id === curr);
                        return (p1?.limit || 0) < (p2?.limit || 0) ? prev : curr;
                      });
                      const platform = PLATFORMS.find(p => p.id === mostRestrictive);
                      const isOver = content.length > (platform?.limit || 0);
                      return (
                        <div className="flex items-center gap-2">
                          {platform && <platform.icon className={cn("w-3 h-3", platform.color)} />}
                          <span className={cn("font-mono", isOver ? "text-red-500 font-bold" : "text-theme-text")}>
                            {content.length}/{platform?.limit}
                          </span>
                        </div>
                      );
                    })()}
                  </div>
                </div>
              )}
              <div className="h-[1px] bg-theme-border" />
              {!isAdmin && (
                <div className="flex justify-between text-lg font-bold">
                  <span className="text-theme-text [text-shadow:var(--text-shadow-theme)]">Total</span>
                  <span className="font-mono text-theme-text [text-shadow:var(--text-shadow-theme)]">
                    {`$${(totalCost / 100).toFixed(2)}`}
                  </span>
                </div>
              )}
              {isAdmin && (
                <div className="flex justify-between text-lg font-bold">
                  <span className="text-theme-text [text-shadow:var(--text-shadow-theme)]">Admin Access</span>
                  <span className="font-mono text-emerald-500 [text-shadow:var(--text-shadow-theme)]">UNLIMITED</span>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <button 
                disabled={!canSend || isSending}
                onClick={handleSend}
                className={cn(
                  "flex-1 py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-3 shadow-[var(--shadow-theme)]",
                  canSend && !isSending
                    ? "bg-emerald-500 hover:bg-emerald-600 text-white hover:scale-[1.01] active:scale-[0.99] shadow-lg shadow-emerald-500/20"
                    : theme.isLight 
                      ? "bg-theme-text/5 text-theme-text/30 border border-theme-border cursor-not-allowed"
                      : "bg-theme-bg-accent text-theme-subtext border border-theme-border cursor-not-allowed opacity-50"
                )}
              >
                {isSending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Broadcast Post
                  </>
                )}
              </button>
            </div>

            <button 
              disabled={selectedChannels.length === 0}
              onClick={() => setIsPreviewOpen(true)}
              className={cn(
                "w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-3 border border-theme-border shadow-sm",
                selectedChannels.length > 0
                  ? "bg-theme-text/10 text-theme-text hover:bg-theme-text/20"
                  : theme.isLight 
                    ? "bg-theme-text/5 text-theme-text/30 cursor-not-allowed"
                    : "bg-transparent text-theme-text/50 cursor-not-allowed"
              )}
            >
              <Eye className="w-4 h-4" />
              Preview Layouts
            </button>

            {!isAdmin && !isActive && selectedChannels.length > 0 && (
              <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <p className="text-[10px] text-red-500 font-bold leading-tight">
                  Your 30-day pass has expired. Please replenish to continue.
                </p>
              </div>
            )}

            {!isAdmin && isActive && credits < totalCost && selectedChannels.length > 0 && (
              <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <p className="text-[10px] text-red-500 font-bold leading-tight">
                  Insufficient credits for {selectedChannels.length} channels. Total cost: ${(totalCost / 100).toFixed(2)}.
                </p>
              </div>
            )}

            {isOverLimit && (
              <div className="flex items-start gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <p className="text-[10px] text-red-500 font-bold leading-tight">
                  Character limit exceeded for one or more platforms.
                </p>
              </div>
            )}

            {message && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "p-5 rounded-2xl flex flex-col gap-4 shadow-xl border backdrop-blur-sm",
                  message.type === "success" 
                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" 
                    : "bg-red-500/10 border-red-500/20 text-red-400"
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={cn(
                      "p-1.5 rounded-lg shrink-0 mt-0.5",
                      message.type === "success" ? "bg-emerald-500/20" : "bg-red-500/20"
                    )}>
                      {message.type === "success" ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black uppercase tracking-widest">
                        {message.type === "success" ? "Broadcast Success" : "Broadcast Error"}
                      </p>
                      <p className="text-xs font-bold leading-relaxed">{message.text}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setMessage(null)}
                    className="p-1.5 hover:bg-theme-text/10 rounded-lg transition-colors shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                
                {message.nextSteps && (
                  <div className={cn(
                    "space-y-2 pt-4 border-t",
                    message.type === "success" ? "border-emerald-500/10" : "border-red-500/10"
                  )}>
                    <div className="flex items-center gap-2">
                      <Info className="w-3 h-3 opacity-40" />
                      <p className="text-[9px] uppercase tracking-[0.15em] font-black opacity-40">Troubleshooting Guide</p>
                    </div>
                    <ul className="space-y-2">
                      {message.nextSteps.map((step, i) => (
                        <li key={i} className="text-[10px] md:text-xs leading-relaxed flex items-start gap-2.5 opacity-90 group transition-opacity hover:opacity-100">
                          <ArrowUpRight className="w-2.5 h-2.5 mt-0.5 shrink-0 opacity-40 group-hover:opacity-100 transition-all group-hover:translate-x-0.5" />
                          <span className="font-medium">{step}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Preview Modal */}
      <AnimatePresence>
        {isPreviewOpen && (
          <div className="fixed inset-0 bg-theme-bg/95 backdrop-blur-md z-[60] flex items-center justify-center p-4 md:p-12">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="max-w-6xl w-full h-full flex flex-col space-y-6 md:space-y-8"
            >
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h2 className="text-xl md:text-2xl font-display font-black tracking-tighter uppercase text-theme-text [text-shadow:var(--text-shadow-theme)]">Broadcast Preview</h2>
                  <p className="text-[10px] md:text-xs text-theme-subtext uppercase tracking-widest font-bold">Simulated platform rendering</p>
                </div>
                <button 
                  onClick={() => setIsPreviewOpen(false)}
                  className="p-2 md:p-3 bg-theme-text/5 hover:bg-theme-text/10 rounded-full transition-colors text-theme-text"
                >
                  <X className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto pr-4 space-y-12 pb-12 custom-scrollbar">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {Array.from(new Set(selectedChannels.map(c => c.platformId))).map((platformId: any) => {
                    const platform = PLATFORMS.find(p => p.id === platformId);
                    if (!platform) return null;
                    return (
                      <div key={platformId as string} className="space-y-4">
                        <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full border w-fit mb-4", `bg-${platform.brand}/10 border-${platform.brand}/20`)}>
                          <platform.icon className={cn("w-4 h-4", platform.color)} />
                          <span className="text-[10px] font-black uppercase tracking-widest text-theme-text">{platform.name}</span>
                        </div>
                        <div className="bg-theme-bg-accent/60 border border-theme-border rounded-3xl overflow-hidden shadow-xl">
                          <PlatformPreviewTemplate platformId={platformId as string} content={content} isPaid={isPaid} media={mediaFile} selectedChannels={selectedChannels} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PlatformPreviewTemplate({ platformId, content, isPaid, media, selectedChannels }: { platformId: string, content: string, isPaid: boolean, media?: { url: string, type: 'image' | 'video' } | null, selectedChannels: Array<{ platformId: string, accountId: string }> }) {
  const user = auth.currentUser;
  const name = user?.displayName || "Syphn User";
  const handle = user?.email?.split("@")[0] || "syphn_user";
  const watermark = "\n\nSent via Syphn";
  const finalContent = isPaid ? content : `${content}${watermark}`;

  const MediaPreview = () => {
    if (!media) return null;
    return (
      <div className="mt-3 rounded-xl overflow-hidden border border-theme-border relative group">
        {media.type === 'image' ? (
          <img src={media.url} alt="Post media" className="w-full h-auto object-cover" />
        ) : (
          <div className="relative aspect-video bg-black flex items-center justify-center">
            <video src={media.url} className="w-full h-full object-contain" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <Film className="w-8 h-8 text-theme-text/60" />
            </div>
          </div>
        )}
        {!isPaid && (
          <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/50 backdrop-blur-sm rounded text-[10px] font-black uppercase tracking-widest text-white/90 pointer-events-none select-none border border-white/10">
            Sent via Syphn
          </div>
        )}
      </div>
    );
  };

  switch (platformId) {
    case "twitter":
      return (
        <div className="p-6 space-y-4 bg-theme-bg-accent/60 text-theme-text font-sans">
          <div className="flex gap-3">
            <div className="w-12 h-12 rounded-full bg-theme-text/10 shrink-0" />
            <div className="space-y-1 flex-1">
              <div className="flex items-center gap-1">
                <span className="font-bold">{name}</span>
                <span className="text-theme-text/60 text-sm font-bold">@{handle} · 1m</span>
              </div>
              <p className={cn(
                "text-[15px] leading-normal whitespace-pre-wrap",
                !finalContent && "text-theme-subtext/20 italic"
              )}>
                {finalContent || "Your post content will appear here..."}
              </p>
              <MediaPreview />
              <div className="flex justify-between text-theme-text/60 font-bold pt-4 max-w-xs">
                <div className="w-4 h-4 rounded border border-theme-border" />
                <div className="w-4 h-4 rounded border border-theme-border" />
                <div className="w-4 h-4 rounded border border-theme-border" />
                <div className="w-4 h-4 rounded border border-theme-border" />
              </div>
            </div>
          </div>
        </div>
      );
    case "instagram":
      return (
        <div className="bg-theme-bg-accent/60 text-theme-text font-sans">
          <div className="p-3 flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-[1.5px]">
              <div className="w-full h-full rounded-full bg-theme-bg-accent" />
            </div>
            <span className="text-xs font-bold">{handle}</span>
          </div>
            <div className="aspect-square bg-theme-text/5 flex items-center justify-center overflow-hidden relative">
              {media ? (
                <>
                  {media.type === 'image' ? (
                    <img src={media.url} alt="Post media" className="w-full h-full object-cover" />
                  ) : (
                    <video src={media.url} className="w-full h-full object-cover" />
                  )}
                  {!isPaid && (
                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/50 backdrop-blur-sm rounded text-[10px] font-black uppercase tracking-widest text-white/90 pointer-events-none select-none border border-white/10">
                      Sent via Syphn
                    </div>
                  )}
                </>
              ) : (
                <p className="text-lg font-medium italic opacity-40">Visual asset placeholder</p>
              )}
            </div>
          <div className="p-4 space-y-2">
            <div className="flex gap-4">
              <div className="w-5 h-5 rounded-full border border-theme-border" />
              <div className="w-5 h-5 rounded-full border border-theme-border" />
              <div className="w-5 h-5 rounded-full border border-theme-border" />
            </div>
            <p className="text-sm">
              <span className="font-bold mr-2">{handle}</span>
              <span className={cn(
                "whitespace-pre-wrap",
                !finalContent ? "text-theme-text/40 italic font-bold" : "text-theme-text/90"
              )}>
                {finalContent || "Your caption will appear here..."}
              </span>
            </p>
            <p className="text-[10px] text-theme-text/60 uppercase font-bold">1 minute ago</p>
          </div>
        </div>
      );
    case "facebook":
      return (
        <div className="p-4 bg-theme-bg-accent/60 text-theme-text font-sans space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-theme-text/10" />
            <div>
              <div className="font-bold text-sm">{name}</div>
              <div className="text-xs text-theme-text/60 font-bold">1m · Public</div>
            </div>
          </div>
          <p className={cn(
            "text-sm whitespace-pre-wrap",
            !finalContent && "text-theme-text/40 italic font-bold"
          )}>
            {finalContent || "What's on your mind?"}
          </p>
          <MediaPreview />
          <div className="h-[1px] bg-theme-border/10" />
          <div className="flex justify-around text-sm font-black text-theme-text [text-shadow:var(--text-shadow-theme)]">
            <span>Like</span>
            <span>Comment</span>
            <span>Share</span>
          </div>
        </div>
      );
    case "linkedin":
      return (
        <div className="p-4 bg-theme-bg-accent/60 text-theme-text font-sans space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-theme-text/10" />
            <div>
              <div className="font-bold text-sm">{name}</div>
              <div className="text-xs text-theme-text font-black uppercase tracking-tighter [text-shadow:var(--text-shadow-theme)]">Syphn Power User</div>
              <div className="text-xs text-theme-text/60 font-bold">1m · Edited</div>
            </div>
          </div>
          <p className={cn(
            "text-sm whitespace-pre-wrap",
            !finalContent && "text-theme-text/40 italic font-bold"
          )}>
            {finalContent || "Share your professional update..."}
          </p>
          <MediaPreview />
          <div className="h-[1px] bg-theme-border/10" />
          <div className="flex gap-6 text-xs font-black text-theme-text [text-shadow:var(--text-shadow-theme)]">
            <span>Like</span>
            <span>Comment</span>
            <span>Repost</span>
            <span>Send</span>
          </div>
        </div>
      );
    case "youtube":
      return (
        <div className="bg-theme-bg-accent/60 text-theme-text font-sans">
          <div className="aspect-video bg-theme-text/5 flex items-center justify-center overflow-hidden relative">
            {media ? (
              <>
                {media.type === 'video' ? (
                  <video src={media.url} className="w-full h-full object-contain" />
                ) : (
                  <img src={media.url} alt="Thumbnail" className="w-full h-full object-cover" />
                )}
                {!isPaid && (
                  <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/50 backdrop-blur-sm rounded text-[10px] font-black uppercase tracking-widest text-white/90 pointer-events-none select-none border border-white/10">
                    Sent via Syphn
                  </div>
                )}
              </>
            ) : (
              <div className="text-center space-y-2">
                <Youtube className="w-12 h-12 text-red-600 mx-auto" />
                <p className="text-sm text-theme-text/60 font-bold italic">Video content required</p>
              </div>
            )}
          </div>
          <div className="p-4 space-y-4">
            <h3 className={cn(
              "text-lg font-bold line-clamp-2",
              !finalContent && "text-theme-subtext/20 italic"
            )}>
              {finalContent.split('\n')[0] || "Your video title here..."}
            </h3>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-theme-text/10" />
              <div className="flex-1">
                <div className="text-sm font-bold">{name}</div>
                <div className="text-xs text-theme-text/60 font-bold">1.2M subscribers</div>
              </div>
              <button className="px-4 py-2 bg-theme-text text-theme-bg-accent rounded-full text-sm font-bold">Subscribe</button>
            </div>
            <div className="p-3 bg-theme-text/5 rounded-xl text-sm whitespace-pre-wrap">
              {finalContent || <span className="text-theme-text/40 italic font-bold">Your video description will appear here...</span>}
            </div>
          </div>
        </div>
      );
    case "tiktok":
      return (
        <div className="relative aspect-[9/16] bg-theme-bg-accent text-theme-text font-sans overflow-hidden max-w-[300px] mx-auto">
          <div className="absolute inset-0 flex items-center justify-center">
            {media ? (
              <>
                {media.type === 'video' ? (
                  <video src={media.url} className="w-full h-full object-cover" />
                ) : (
                  <img src={media.url} alt="TikTok Background" className="w-full h-full object-cover opacity-50" />
                )}
                {!isPaid && (
                  <div className="absolute bottom-20 right-2 px-2 py-1 bg-black/50 backdrop-blur-sm rounded text-[10px] font-black uppercase tracking-widest text-white/90 pointer-events-none select-none border border-white/10">
                    Sent via Syphn
                  </div>
                )}
              </>
            ) : (
              <Music2 className="w-12 h-12 text-cyan-400 animate-pulse" />
            )}
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-theme-bg-accent/60" />
          <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2">
            <div className="font-bold text-sm">@{handle}</div>
            <p className={cn(
              "text-xs line-clamp-3 whitespace-pre-wrap",
              !finalContent && "text-theme-subtext/20 italic"
            )}>
              {finalContent || "Your TikTok caption..."}
            </p>
            <div className="flex items-center gap-2">
              <Music2 className="w-3 h-3" />
              <span className="text-[10px]">Original Sound - {name}</span>
            </div>
          </div>
          <div className="absolute right-2 bottom-20 flex flex-col gap-6 items-center">
            <div className="w-10 h-10 rounded-full bg-theme-text/10 border border-theme-border" />
            <div className="w-8 h-8 rounded-full bg-theme-text/10" />
            <div className="w-8 h-8 rounded-full bg-theme-text/10" />
            <div className="w-8 h-8 rounded-full bg-theme-text/10" />
          </div>
        </div>
      );
    case "pinterest":
      return (
        <div className="bg-theme-bg-accent/60 text-theme-text font-sans rounded-3xl overflow-hidden border border-theme-border">
          <div className="bg-theme-text/5 flex items-center justify-center overflow-hidden relative">
            {media ? (
              <>
                <img src={media.url} alt="Pin" className="w-full h-auto" />
                {!isPaid && (
                  <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/50 backdrop-blur-sm rounded text-[10px] font-black uppercase tracking-widest text-white/90 pointer-events-none select-none border border-white/10">
                    Sent via Syphn
                  </div>
                )}
              </>
            ) : (
              <div className="p-12 text-center">
                <Pin className="w-12 h-12 text-red-600 mx-auto mb-4" />
                <p className="text-sm text-theme-text/60 font-bold italic">Visual inspiration</p>
              </div>
            )}
          </div>
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded-full bg-theme-text/10" />
                <div className="w-8 h-8 rounded-full bg-theme-text/10" />
              </div>
              <button className="px-4 py-2 bg-red-600 text-white rounded-full font-bold text-sm">Save</button>
            </div>
            <p className={cn(
              "text-sm leading-relaxed whitespace-pre-wrap",
              !finalContent && "text-theme-text/60 italic font-bold"
            )}>
              {finalContent || "Your pin description..."}
            </p>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-theme-text/10" />
              <span className="text-xs font-bold">{name}</span>
            </div>
          </div>
        </div>
      );
    case "threads":
      return (
        <div className="p-6 space-y-4 bg-theme-bg-accent/60 text-theme-text font-sans">
          <div className="flex gap-3">
            <div className="flex flex-col items-center gap-2">
              <div className="w-10 h-10 rounded-full bg-theme-text/10 shrink-0" />
              <div className="w-[2px] flex-1 bg-theme-text/10 rounded-full" />
            </div>
            <div className="space-y-1 flex-1 pb-4">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm">{handle}</span>
                <span className="text-theme-text/60 text-xs font-bold">1m</span>
              </div>
              <p className={cn(
                "text-sm leading-normal whitespace-pre-wrap",
                !finalContent && "text-theme-subtext/20 italic"
              )}>
                {finalContent || "What's new?"}
              </p>
              <MediaPreview />
              <div className="flex flex-wrap gap-3 pt-4">
                {Array.from(new Set(selectedChannels.map(c => c.platformId))).map(platformId => {
                  const platform = PLATFORMS.find(p => p.id === platformId);
                  if (!platform) return null;
                  const Icon = platform.icon;
                  return (
                    <div key={platformId} className={cn("p-1.5 rounded-lg border bg-theme-text/5", `border-${platform.brand}/20`)}>
                      <Icon className={cn("w-3.5 h-3.5", platform.color)} />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      );
    default:
      return <div className="p-6 text-theme-text/60 italic">Preview not available</div>;
  }
}

function SettingsView({ user, theme, apiMode, onRefreshStatus }: { user: any, theme: any, apiMode: "demo" | "production", onRefreshStatus: () => void }) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await onRefreshStatus();
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 md:space-y-12">
      <div className="space-y-2">
        <h2 className="text-2xl md:text-3xl font-mono font-bold tracking-tight text-theme-text [text-shadow:var(--text-shadow-theme)]">Settings</h2>
        <p className="text-theme-subtext text-xs md:text-sm">Manage your account and broadcast preferences.</p>
      </div>

      <div className="space-y-6 md:space-y-8">
        {/* Account Info */}
        <section className={cn(
          "border border-theme-border rounded-3xl p-6 md:p-8 space-y-6",
          theme.isLight ? "bg-white/40 shadow-sm" : "bg-theme-bg/40"
        )}>
          <div className="flex items-center gap-4">
            <div className="p-2.5 md:p-3 bg-theme-text/5 rounded-2xl border border-theme-border">
              <UserIcon className="w-5 md:w-6 h-5 md:h-6 text-theme-text/60" />
            </div>
            <div>
              <h3 className="text-base md:text-lg font-bold tracking-tight">Account Profile</h3>
              <p className="text-[10px] md:text-xs text-theme-subtext">Your personal information</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-black text-theme-subtext">Email Address</label>
              <div className="p-4 bg-theme-text/5 border border-theme-border rounded-xl text-theme-text font-medium flex justify-between items-center">
                <span>{user?.email}</span>
                <span className="text-[8px] opacity-30 font-mono">({user?.email?.toLowerCase() === 'ghozt.app@gmail.com' ? 'ADMIN' : 'USER'})</span>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-black text-theme-subtext">User ID</label>
              <div className="p-4 bg-theme-text/5 border border-theme-border rounded-xl text-theme-text font-mono text-xs">
                {user?.uid}
              </div>
            </div>
          </div>
        </section>

        {/* Mobile App Installation */}
        <section className={cn(
          "border border-theme-border rounded-3xl p-8 space-y-6 bg-gradient-to-br",
          theme.isLight ? "from-sky-500/10 to-transparent" : "from-theme-primary/20 to-transparent"
        )}>
          <div className="flex items-center gap-4">
            <div className="p-3 bg-theme-text/5 rounded-2xl border border-theme-border">
              <Zap className="w-6 h-6 text-theme-text/60" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold tracking-tight">Social Mobile App</h3>
                <span className="px-2 py-0.5 bg-theme-text/10 rounded-full text-[8px] font-black uppercase tracking-widest">PWA</span>
              </div>
              <p className="text-xs text-theme-subtext">Install Syphn to your home screen for a native experience.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-theme-bg/60 border border-theme-border rounded-2xl space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-theme-text/5 flex items-center justify-center text-[10px] font-bold">1</div>
                <p className="text-sm font-bold">For iOS (Safari)</p>
              </div>
              <p className="text-xs text-theme-subtext leading-relaxed">
                Tap the <Share2 className="w-3 h-3 inline-block mx-1" /> "Share" icon in Safari and select <strong>"Add to Home Screen"</strong>.
              </p>
            </div>
            <div className="p-4 bg-theme-bg/60 border border-theme-border rounded-2xl space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-theme-text/5 flex items-center justify-center text-[10px] font-bold">2</div>
                <p className="text-sm font-bold">For Android (Chrome)</p>
              </div>
              <p className="text-xs text-theme-subtext leading-relaxed">
                Tap the three dots <Info className="w-3 h-3 inline-block mx-1" /> menu and select <strong>"Install App"</strong>.
              </p>
            </div>
          </div>
        </section>

        {/* API Configuration - Admin Only */}
        {user?.email?.toLowerCase() === 'ghozt.app@gmail.com' && (
          <section className={cn(
            "border border-theme-border rounded-3xl p-8 space-y-6",
            theme.isLight ? "bg-white/40 shadow-sm" : "bg-theme-bg/40"
          )}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-theme-text/5 rounded-2xl border border-theme-border">
                  <Key className="w-6 h-6 text-theme-text/60" />
                </div>
                <div>
                  <h3 className="text-lg font-bold tracking-tight">API Configuration (Admin)</h3>
                  <p className="text-xs text-theme-subtext">Manage your Syphn broadcast keys</p>
                </div>
              </div>
              <button 
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="p-2 hover:bg-theme-text/5 rounded-xl transition-colors"
                title="Refresh API Status"
              >
                <RefreshCw className={cn("w-5 h-5 text-theme-subtext", isRefreshing && "animate-spin")} />
              </button>
            </div>

            <div className="space-y-4">
              <div className={cn(
                "p-4 rounded-2xl border flex items-center justify-between",
                apiMode === "production" ? "bg-emerald-500/5 border-emerald-500/20" : "bg-amber-500/5 border-amber-500/20"
              )}>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-theme-text">API Mode</p>
                  <p className="text-[10px] text-theme-subtext uppercase tracking-widest font-black">
                    {apiMode === "production" ? "Production (Real Socials)" : "Demo (Simulated)"}
                  </p>
                </div>
                <div className={cn(
                  "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest",
                  apiMode === "production" ? "bg-emerald-500 text-white" : "bg-amber-500 text-white"
                )}>
                  {apiMode}
                </div>
              </div>

              <div className="p-6 bg-amber-500/5 border border-amber-500/20 rounded-2xl space-y-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-amber-500">Developer Note</p>
                    <p className="text-xs text-amber-500/80 leading-relaxed">
                      Your Syphn API key is managed securely via AI Studio Secrets. To update your key, please use the "Secrets" panel in the AI Studio settings menu.
                    </p>
                  </div>
                </div>
                <div className="pt-2">
                  <a 
                    href="https://syphn.app/dashboard/api" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 rounded-lg text-[10px] font-black uppercase tracking-widest text-amber-500 transition-all"
                  >
                    Get New API Key
                    <ArrowUpRight className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Preferences */}
        <section className="bg-theme-bg/40 border border-theme-border rounded-3xl p-8 space-y-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-theme-text/5 rounded-2xl border border-theme-border">
              <Shield className="w-6 h-6 text-theme-text/60" />
            </div>
            <div>
              <h3 className="text-lg font-bold tracking-tight">Preferences</h3>
              <p className="text-xs text-theme-subtext">Privacy and display settings</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-theme-text/5 border border-theme-border rounded-2xl">
              <div className="space-y-0.5">
                <p className="text-sm font-bold">Public Profile</p>
                <p className="text-[10px] text-theme-subtext uppercase tracking-widest font-black">Allow others to see your broadcast history</p>
              </div>
              <div className="w-12 h-6 bg-theme-text/10 rounded-full relative cursor-not-allowed opacity-50">
                <div className="absolute left-1 top-1 w-4 h-4 bg-theme-text/20 rounded-full" />
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-theme-text/5 border border-theme-border rounded-2xl">
              <div className="space-y-0.5">
                <p className="text-sm font-bold">Email Notifications</p>
                <p className="text-[10px] text-theme-subtext uppercase tracking-widest font-black">Receive alerts for successful broadcasts</p>
              </div>
              <div className="w-12 h-6 bg-emerald-500/20 rounded-full relative cursor-not-allowed">
                <div className="absolute right-1 top-1 w-4 h-4 bg-emerald-500 rounded-full" />
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function ConnectionsManager({ connections, theme }: { connections: any, theme: any }) {
  const [isConnecting, setIsConnecting] = useState<string | null>(null);
  const [hoveredPlatform, setHoveredPlatform] = useState<string | null>(null);

  const handleAddAccount = async (platformId: string) => {
    setIsConnecting(platformId);
    try {
      await toggleConnection(platformId, true);
      toast.success("Account connected successfully!");
    } catch (err: any) {
      console.error("Failed to add account:", err);
      toast.error(err.message || "Failed to add account");
    } finally {
      setIsConnecting(null);
    }
  };

  const handleRemoveAccount = async (platformId: string, accountId: string) => {
    try {
      await removeAccount(platformId, accountId);
    } catch (err) {
      console.error("Failed to remove account:", err);
    }
  };

  return (
    <div className="space-y-8 md:space-y-12">
      <div className="space-y-2">
        <h2 className="text-2xl md:text-3xl font-display font-black text-theme-text uppercase tracking-tighter [text-shadow:var(--text-shadow-theme)]">Social Connections</h2>
        <p className="text-theme-subtext text-xs md:text-sm font-black uppercase tracking-widest">Link multiple accounts per platform to expand your reach.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {PLATFORMS.map((platform) => {
          const platformAccounts = Array.isArray(connections[platform.id]) 
            ? connections[platform.id] 
            : connections[platform.id] ? [{ ...connections[platform.id], id: 'legacy' }] : [];
          const isConnected = platformAccounts.length > 0;
          const Icon = platform.icon;

          return (
            <div 
              key={platform.id}
              onMouseEnter={() => setHoveredPlatform(platform.id)}
              onMouseLeave={() => setHoveredPlatform(null)}
              className={cn(
                "relative border border-theme-border rounded-[2rem] overflow-hidden transition-all duration-500 shadow-2xl group",
                theme.isLight ? "bg-white" : "bg-theme-bg",
                isConnected ? "ring-1 ring-emerald-500/20" : "hover:border-theme-text/20"
              )}
            >
              <div className="p-6 md:p-8 space-y-6">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4 md:gap-6">
                    <div className={cn(
                      "p-4 md:p-5 rounded-2xl border transition-all duration-500",
                      isConnected ? `bg-${platform.brand}/10 border-${platform.brand}/30 scale-110` : "bg-theme-text/5 border-theme-border"
                    )}>
                      <Icon className={cn("w-6 md:w-8 h-6 md:h-8", isConnected ? platform.color : "text-theme-text/40")} />
                    </div>
                    <div className="space-y-1">
                      <h3 className="text-sm md:text-base font-display font-black text-theme-text uppercase tracking-widest">{platform.name}</h3>
                      <p className="text-[10px] text-theme-subtext font-mono font-bold uppercase">
                        {platformAccounts.length} Account{platformAccounts.length !== 1 ? 's' : ''} Connected
                      </p>
                    </div>
                  </div>

                  <button
                    disabled={isConnecting === platform.id}
                    onClick={() => handleAddAccount(platform.id)}
                    className={cn(
                      "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all duration-300 shadow-lg active:scale-95 flex items-center gap-2",
                      "bg-theme-text text-theme-bg hover:shadow-theme-text/20"
                    )}
                  >
                    {isConnecting === platform.id ? (
                      <Loader2 className="w-4 h-4 animate-spin mx-auto" />
                    ) : (
                      <>
                        <Plus className="w-3 h-3" />
                        Add Account
                      </>
                    )}
                  </button>
                </div>

                {isConnected && (
                  <div className="space-y-3">
                    <div className="h-px bg-theme-border/50 w-full" />
                    {platformAccounts.map((account: any, idx: number) => (
                      <div key={account.id || idx} className="flex items-center justify-between p-4 bg-theme-text/5 border border-theme-border/50 rounded-2xl group/account">
                        <div className="space-y-0.5">
                          <p className="text-xs font-bold flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            {platform.handlePrefix}{account.username}
                          </p>
                          <p className="text-[9px] text-theme-subtext font-mono uppercase tracking-tighter">
                            Connected {format(new Date(account.connectedAt), 'MMM d, yyyy')}
                          </p>
                        </div>
                        <button 
                          onClick={() => handleRemoveAccount(platform.id, account.id)}
                          className="p-2 text-theme-subtext hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover/account:opacity-100"
                          title="Remove Account"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="h-px bg-theme-border/50 w-full" />

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-theme-subtext">Quick Tip</p>
                    <div className="flex-1 h-px bg-theme-border/30 mx-4" />
                  </div>
                  <p className="text-[11px] text-theme-subtext leading-relaxed font-medium">
                    You can link as many {platform.name} accounts as you need. Each broadcast to a specific account costs 10 credits (10¢).
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CountdownTimer({ expiresAt, theme }: { expiresAt: string | null, theme: any }) {
  const [timeLeft, setTimeLeft] = useState<string | null>(null);

  useEffect(() => {
    if (!expiresAt) return;

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const expiry = new Date(expiresAt).getTime();
      const distance = expiry - now;

      if (distance < 0) {
        setTimeLeft("Expired");
        clearInterval(interval);
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      if (days > 0) {
        setTimeLeft(`${days}d ${hours}h`);
      } else {
        setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [expiresAt]);

  if (!expiresAt || timeLeft === "Expired") return null;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full border shadow-sm",
        theme.isLight ? "bg-amber-500/5 border-amber-500/20" : "bg-amber-500/10 border-amber-500/30"
      )}
    >
      <Clock className="w-3 h-3 text-amber-500 animate-pulse" />
      <div className="flex flex-col">
        <span className="text-[7px] text-amber-500/60 font-black uppercase tracking-widest leading-none">Bonus Expiry</span>
        <span className="text-[9px] font-mono font-black text-amber-500 leading-none mt-0.5">{timeLeft}</span>
      </div>
    </motion.div>
  );
}

function Overview({ user, credits, connections, theme, onNavigate }: { user: any, credits: number, connections: any, theme: any, onNavigate: (tab: any) => void }) {
  const [recentPosts, setRecentPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, "posts"),
      where("uid", "==", user.uid),
      orderBy("createdAt", "desc"),
      limit(3)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setRecentPosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user.uid]);

  const connectedCount = Object.keys(connections).length;
  const isAdmin = user?.email?.toLowerCase() === 'ghozt.app@gmail.com';

  return (
    <div className="space-y-8 md:space-y-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-2xl md:text-3xl font-mono font-bold tracking-tight text-theme-text [text-shadow:var(--text-shadow-theme)]">Overview</h2>
          <p className="text-theme-subtext text-xs md:text-sm mt-1">Welcome back, {user.displayName || 'Broadcaster'}. Here's what's happening.</p>
        </div>
        <button 
          onClick={() => onNavigate("compose")}
          className="px-6 py-3 bg-theme-text text-theme-bg rounded-xl font-black uppercase tracking-widest text-[10px] shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2"
        >
          <Plus className="w-3.5 h-3.5" />
          New Broadcast
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="p-2 bg-theme-text/5 rounded-xl border border-theme-border/50">
              <CreditCard className="w-4 h-4 text-theme-text/60" />
            </div>
          </div>
          <div>
            <div className="text-[9px] text-theme-subtext uppercase tracking-widest font-black mb-1">Available Balance</div>
            <div className={cn(
              "text-2xl font-mono font-bold tracking-tight",
              credits === 0 && !isAdmin ? "text-rose-500" : "text-theme-text"
            )}>
              {isAdmin ? "∞" : `$${(credits / 100).toFixed(2)}`}
            </div>
            <div className="text-[9px] text-theme-subtext/60 font-medium mt-2">
              {isAdmin ? "Unlimited Admin Access" : `${Math.floor(credits / 10)} broadcasts remaining`}
            </div>
          </div>
        </div>

        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="p-2 bg-theme-text/5 rounded-xl border border-theme-border/50">
              <Link2 className="w-4 h-4 text-theme-text/60" />
            </div>
            <div className={cn(
              "px-2 py-1 rounded-full text-[9px] font-black uppercase tracking-wider",
              connectedCount > 0 ? "bg-emerald-500/10 text-emerald-500" : "bg-amber-500/10 text-amber-500"
            )}>
              {connectedCount}/{PLATFORMS.length} Active
            </div>
          </div>
          <div>
            <div className="text-[9px] text-theme-subtext uppercase tracking-widest font-black mb-1">Connections</div>
            <div className="text-2xl font-mono font-bold tracking-tight text-theme-text">{connectedCount}</div>
            <button 
              onClick={() => onNavigate("connections")}
              className="text-[9px] text-theme-primary font-black uppercase tracking-widest mt-2 hover:underline"
            >
              Manage Connections
            </button>
          </div>
        </div>

        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="p-2 bg-theme-text/5 rounded-xl border border-theme-border/50">
              <History className="w-4 h-4 text-theme-text/60" />
            </div>
          </div>
          <div>
            <div className="text-[9px] text-theme-subtext uppercase tracking-widest font-black mb-1">Total Broadcasts</div>
            <div className="text-2xl font-mono font-bold tracking-tight text-theme-text">{recentPosts.length > 0 ? 'Active' : '0'}</div>
            <button 
              onClick={() => onNavigate("history")}
              className="text-[9px] text-theme-primary font-black uppercase tracking-widest mt-2 hover:underline"
            >
              View History
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base md:text-lg font-bold tracking-tight">Recent Activity</h3>
            <button 
              onClick={() => onNavigate("history")}
              className="text-[9px] font-black uppercase tracking-widest text-theme-subtext hover:text-theme-text transition-colors"
            >
              View All
            </button>
          </div>
          
          {loading ? (
            <div className="py-12 flex justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-theme-subtext" />
            </div>
          ) : recentPosts.length > 0 ? (
            <div className="space-y-4">
              {recentPosts.map((post) => (
                <div key={post.id} className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl flex items-center justify-between group hover:border-theme-text/20 transition-all">
                  <div className="space-y-1 min-w-0">
                    <p className="text-xs font-medium text-theme-text truncate pr-4">{post.content}</p>
                    <div className="flex items-center gap-2">
                      <div className="flex -space-x-1">
                        {post.platforms.map((p: string) => {
                          const platform = PLATFORMS.find(plat => plat.id === p);
                          return platform ? <platform.icon key={p} className={cn("w-2.5 h-2.5", platform.color)} /> : null;
                        })}
                      </div>
                      <span className="text-[9px] text-theme-subtext font-bold uppercase tracking-tighter">
                        {post.createdAt ? format(post.createdAt.toDate(), 'MMM d, h:mm a') : 'Just now'}
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-theme-subtext opacity-0 group-hover:opacity-100 transition-all" />
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-theme-text/5 flex items-center justify-center mx-auto">
                <Send className="w-6 h-6 text-theme-subtext/20" />
              </div>
              <p className="text-[10px] font-black uppercase tracking-widest text-theme-subtext">No broadcasts yet</p>
            </div>
          )}
        </div>

        <div className="bg-theme-bg/40 border border-theme-border rounded-3xl p-6 md:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base md:text-lg font-bold tracking-tight">Quick Actions</h3>
            <Zap className="w-5 h-5 text-theme-text/40" />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button 
              onClick={() => onNavigate("compose")}
              className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl text-left space-y-2 hover:bg-theme-text/10 transition-all group"
            >
              <div className="p-2 bg-theme-text/5 rounded-lg w-fit group-hover:bg-theme-text/10 transition-colors">
                <Send className="w-4 h-4 text-theme-text/60" />
              </div>
              <div>
                <p className="text-xs font-bold text-theme-text">Compose Post</p>
                <p className="text-[9px] text-theme-subtext uppercase tracking-widest font-black">Broadcast to all socials</p>
              </div>
            </button>
            <button 
              onClick={() => onNavigate("connections")}
              className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl text-left space-y-2 hover:bg-theme-text/10 transition-all group"
            >
              <div className="p-2 bg-theme-text/5 rounded-lg w-fit group-hover:bg-theme-text/10 transition-colors">
                <Link2 className="w-4 h-4 text-theme-text/60" />
              </div>
              <div>
                <p className="text-xs font-bold text-theme-text">Link Accounts</p>
                <p className="text-[9px] text-theme-subtext uppercase tracking-widest font-black">Connect more platforms</p>
              </div>
            </button>
            <button 
              onClick={() => onNavigate("analytics")}
              className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl text-left space-y-2 hover:bg-theme-text/10 transition-all group"
            >
              <div className="p-2 bg-theme-text/5 rounded-lg w-fit group-hover:bg-theme-text/10 transition-colors">
                <TrendingUp className="w-4 h-4 text-theme-text/60" />
              </div>
              <div>
                <p className="text-xs font-bold text-theme-text">View Stats</p>
                <p className="text-[9px] text-theme-subtext uppercase tracking-widest font-black">Check your performance</p>
              </div>
            </button>
            <button 
              onClick={() => onNavigate("settings")}
              className="p-4 bg-theme-text/5 border border-theme-border rounded-2xl text-left space-y-2 hover:bg-theme-text/10 transition-all group"
            >
              <div className="p-2 bg-theme-text/5 rounded-lg w-fit group-hover:bg-theme-text/10 transition-colors">
                <UserIcon className="w-4 h-4 text-theme-text/60" />
              </div>
              <div>
                <p className="text-xs font-bold text-theme-text">Account Settings</p>
                <p className="text-[9px] text-theme-subtext uppercase tracking-widest font-black">Manage your profile</p>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PostHistory({ user, theme }: { user: any, theme: any }) {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [platformFilter, setPlatformFilter] = useState<string | "all">("all");

  useEffect(() => {
    const q = query(
      collection(db, "posts"),
      where("uid", "==", user.uid),
      orderBy("createdAt", "desc"),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setPosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user.uid]);

  const handleDelete = async (id: string) => {
    setIsDeleting(true);
    try {
      await deletePost(id);
      setDeletingId(null);
    } catch (err) {
      console.error("Failed to delete post:", err);
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredPosts = platformFilter === "all" 
    ? posts 
    : posts.filter(post => post.platforms.includes(platformFilter));

  if (loading) return <div className="py-12 text-center text-theme-text uppercase tracking-widest font-black text-[10px] [text-shadow:var(--text-shadow-theme)]">Loading history...</div>;

  return (
    <div className="space-y-8">
      {/* Filter UI */}
      <div className="flex flex-wrap items-center gap-4 pb-4 border-b border-theme-border/50">
        <div className="flex items-center gap-2 text-[10px] text-theme-subtext uppercase tracking-widest font-black">
          <Filter className="w-3 h-3" />
          Filter by Platform
        </div>
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => setPlatformFilter("all")}
            className={cn(
              "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all border",
              platformFilter === "all" 
                ? "bg-theme-text text-theme-bg border-theme-text" 
                : "bg-theme-text/5 text-theme-subtext border-theme-border hover:border-theme-text/40"
            )}
          >
            All
          </button>
          {PLATFORMS.map((p) => (
            <button 
              key={p.id}
              onClick={() => setPlatformFilter(p.id)}
              className={cn(
                "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all border flex items-center gap-2",
                platformFilter === p.id 
                  ? "bg-theme-text text-theme-bg border-theme-text" 
                  : "bg-theme-text/5 text-theme-subtext border-theme-border hover:border-theme-text/40"
              )}
            >
              <p.icon className="w-3 h-3" />
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {filteredPosts.length === 0 ? (
        <div className="py-24 text-center space-y-4">
          <History className="w-12 h-12 text-theme-subtext/5 mx-auto" />
          <p className="text-theme-text uppercase tracking-widest font-black text-[10px] [text-shadow:var(--text-shadow-theme)]">
            {platformFilter === "all" ? "No posts yet. Start broadcasting!" : `No posts found for ${PLATFORMS.find(p => p.id === platformFilter)?.name}`}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post) => (
        <div 
          key={post.id}
          className={cn(
            "p-4 md:p-6 backdrop-blur-sm border border-theme-border rounded-2xl flex flex-col sm:flex-row items-start gap-4 md:gap-6 group transition-all duration-300",
            theme.isLight 
              ? "bg-white/40 hover:bg-white/60 shadow-sm" 
              : "bg-theme-bg/40 hover:bg-theme-bg/60"
          )}
        >
          {/* Platform Icons Sidebar */}
          <div className="flex flex-row sm:flex-col gap-2 pt-1">
            {post.platforms.map((p: string) => {
              const platform = PLATFORMS.find(plat => plat.id === p);
              const Icon = platform?.icon || Send;
              return (
                <div key={p} className={cn("p-1.5 md:p-2 bg-theme-text/5 rounded-lg border", `border-${platform?.brand}/20`)} title={platform?.name}>
                  <Icon className={cn("w-3.5 md:w-4 h-3.5 md:h-4", platform?.color || "text-theme-text/60")} />
                </div>
              );
            })}
          </div>

          <div className="space-y-3 flex-1 w-full">
            <p className="text-sm md:text-base text-theme-text/80 leading-relaxed break-words">{post.content}</p>
            {post.media && (
              <div className="flex items-center gap-2 px-2 py-1 bg-theme-text/5 rounded-md w-fit">
                {post.media.type === 'image' ? <ImageIcon className="w-3 h-3 text-theme-subtext" /> : <Film className="w-3 h-3 text-theme-subtext" />}
                <span className="text-[9px] md:text-[10px] text-theme-subtext uppercase tracking-widest font-bold">{post.media.type} attached</span>
              </div>
            )}
            <div className="flex items-center gap-4">
              <span className="text-[9px] md:text-[10px] text-theme-subtext font-mono font-bold">
                {post.createdAt?.toDate().toLocaleString()}
              </span>
            </div>
          </div>
          
          <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-start w-full sm:w-auto gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-theme-border/10">
            <div className="flex flex-col items-start sm:items-end gap-1">
              <div className={cn(
                "px-2 py-1 rounded text-[7px] md:text-[8px] font-bold uppercase tracking-widest",
                post.status === "success" ? "bg-emerald-500/10 text-emerald-400" : 
                post.status === "scheduled" ? "bg-sky-500/10 text-sky-400" :
                "bg-red-500/10 text-red-400"
              )}>
                {post.status}
              </div>
              {post.status === "failed" && post.error && (
                <div className="text-[7px] md:text-[8px] text-red-400 font-bold max-w-[150px] text-right">
                  {post.error}
                </div>
              )}
              {post.status === "scheduled" && post.scheduledAt && (
                <div className="flex items-center gap-1 text-[7px] md:text-[8px] text-theme-subtext uppercase tracking-widest font-bold">
                  <Clock className="w-2 h-2" />
                  {post.scheduledAt.toDate().toLocaleString()}
                </div>
              )}
            </div>

            <div className="flex items-center gap-4 sm:flex-col sm:items-end sm:gap-2">
              <div className="text-[10px] md:text-[12px] font-mono text-theme-text font-bold">-${(post.cost / 100).toFixed(2)}</div>
              
              <button 
                onClick={() => setDeletingId(post.id)}
                className="p-2 md:p-2.5 bg-red-500/5 hover:bg-red-500/10 text-red-500/40 hover:text-red-500 border border-red-500/10 hover:border-red-500/30 rounded-xl transition-all sm:opacity-0 sm:group-hover:opacity-100 shadow-sm"
                title="Delete Post"
              >
                <Trash2 className="w-3.5 md:w-4 h-3.5 md:h-4" />
              </button>
            </div>
          </div>
        </div>
      ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deletingId && (
          <div className="fixed inset-0 bg-theme-bg/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 md:p-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={cn(
                "border border-theme-border p-6 md:p-8 rounded-3xl max-w-md w-full space-y-6 shadow-2xl",
                theme.isLight ? "bg-white" : "bg-theme-bg"
              )}
            >
              <div className="space-y-2 text-center">
                <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Trash2 className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="text-xl font-display font-black text-theme-text uppercase tracking-tighter [text-shadow:var(--text-shadow-theme)]">Delete Post?</h3>
              <p className="text-theme-subtext text-sm font-black uppercase tracking-widest [text-shadow:var(--text-shadow-theme)]">This action cannot be undone. The post will be permanently removed from your history.</p>
              </div>
              <div className="flex gap-4">
                <button 
                  disabled={isDeleting}
                  onClick={() => setDeletingId(null)}
                  className="flex-1 py-3 rounded-xl bg-theme-text/5 hover:bg-theme-text/10 text-theme-text font-bold transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button 
                  disabled={isDeleting}
                  onClick={() => handleDelete(deletingId)}
                  className="flex-1 py-3 rounded-xl bg-red-500 hover:bg-red-600 text-white font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-red-500/20 disabled:opacity-50"
                >
                  {isDeleting ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    "Delete"
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
