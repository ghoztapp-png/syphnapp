import { auth, db } from "../firebase";
import { doc, getDoc, setDoc, updateDoc, addDoc, deleteDoc, collection, serverTimestamp, runTransaction, increment, query, orderBy, limit, getDocs } from "firebase/firestore";
import FingerprintJS from '@fingerprintjs/fingerprintjs';
import { handleFirestoreError, OperationType } from "../lib/firebaseUtils";

// Initialize fingerprint agent
const fpPromise = FingerprintJS.load();

export interface PostData {
  content: string;
  channels: Array<{ platformId: string; accountId: string }>;
  scheduledAt?: Date | null;
  media?: { type: 'image' | 'video', name: string } | null;
}

const getMonthKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
};

const incrementUsage = async (type: 'post' | 'revenue', amount: number) => {
  const monthKey = getMonthKey();
  const usageRef = doc(db, "usage", monthKey);
  
  try {
    const usageSnap = await getDoc(usageRef);
    if (!usageSnap.exists()) {
      await setDoc(usageRef, {
        month: monthKey,
        totalPosts: type === 'post' ? amount : 0,
        revenueCents: type === 'revenue' ? amount : 0
      });
    } else {
      await updateDoc(usageRef, {
        totalPosts: type === 'post' ? increment(amount) : increment(0),
        revenueCents: type === 'revenue' ? increment(amount) : increment(0)
      });
    }
  } catch (error) {
    console.error("Usage increment failed:", error);
  }
};

const logTransaction = async (amountCents: number, type: 'topup' | 'deduction') => {
  const user = auth.currentUser;
  if (!user) return;

  try {
    await addDoc(collection(db, "transactions"), {
      uid: user.uid,
      email: user.email,
      amountCents,
      type,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.error("Transaction log failed:", error);
  }
};

export interface UserProfile {
  uid: string;
  email: string;
  credit_balance: number;
  expires_at: string | null;
  credits: number;
  postCount: number;
  deviceId: string;
  isPaid: boolean;
  connections: any;
  createdAt: any;
}

export const isAccessActive = (userProfile: UserProfile | null) => {
  if (!userProfile) return false;
  const now = new Date();
  const expiry = userProfile.expires_at ? new Date(userProfile.expires_at) : null;
  
  return userProfile.credit_balance > 0 && (expiry === null || now < expiry);
};

export const uploadPost = async (post: PostData) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    throw error;
  }
  
  if (!userSnap.exists()) throw new Error("User profile not found");
  
  const userData = userSnap.data() as UserProfile;
  const isAdmin = user?.email?.toLowerCase() === 'ghozt.app@gmail.com';
  
  // 30-Day Pass check
  if (!isAdmin && !isAccessActive(userData)) {
    throw new Error("Your 30-day pass has expired or you have no credits remaining. Please replenish to continue.");
  }

  const isPaid = userData.isPaid || isAdmin;
  const cost = isAdmin ? 0 : 1; // Deduct 1 from credit_balance per post interaction (channels count logic below)
  
  // Note: the original logic subtracted cents. User now wants 'credit_balance' which sounds like 'number of posts'.
  // However, traditionally Syphn uses cents. I will implement 'credit_balance' as 'post credits' as requested.
  const requiredCredits = isAdmin ? 0 : post.channels.length;

  if (!isAdmin && userData.credit_balance < requiredCredits) {
    throw new Error(`Insufficient credits for ${requiredCredits} channels. balance: ${userData.credit_balance}`);
  }

  const finalContent = isPaid ? post.content : `${post.content}\n\nSent via Syphn`;

  // 2. Call the external API or schedule it
  try {
    if (post.scheduledAt && post.scheduledAt > new Date()) {
      // If scheduled for future, deduct credits and record it
      if (!isAdmin) {
        try {
          await updateDoc(userRef, {
            credits: increment(-cost),
            postCount: increment(1)
          });
          await incrementUsage('post', 1);
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
        }
      }
  
      try {
        await addDoc(collection(db, "posts"), {
          uid: user.uid,
          content: finalContent,
          channels: post.channels,
          status: "scheduled",
          cost: cost,
          scheduledAt: post.scheduledAt,
          media: post.media || null,
          createdAt: serverTimestamp()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, "posts");
      }
      return { success: true, scheduled: true };
    }

    // Otherwise, post immediately
    // Call the local server-side API endpoint
    const response = await fetch("/api/upload-post", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        content: finalContent,
        channels: post.channels,
        media: post.media || null
      })
    });

    const responseData = await response.json();

    if (!response.ok) {
      throw new Error(responseData.error || "Failed to upload post via server");
    }

    // 3. Post was successful, NOW deduct credits and record in Firestore
    if (!isAdmin) {
      try {
        await updateDoc(userRef, {
          credit_balance: increment(-requiredCredits),
          credits: increment(-(requiredCredits * 10)), // keep legacy credits in sync if needed
          postCount: increment(1)
        });
        await incrementUsage('post', 1);
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
      }
    }

    try {
      await addDoc(collection(db, "posts"), {
        uid: user.uid,
        content: finalContent,
        channels: post.channels,
        status: "success",
        cost: requiredCredits * 10,
        media: post.media || null,
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, "posts");
    }

    return { success: true, mode: responseData.mode };
  } catch (error) {
    // If API fails, we do NOT deduct credits
    console.error("Post upload failed:", error);
    try {
      await addDoc(collection(db, "posts"), {
        uid: user.uid,
        content: finalContent,
        channels: post.channels,
        status: "failed",
        error: error instanceof Error ? error.message : String(error),
        cost: 0, // No cost for failed posts
        media: post.media || null,
        createdAt: serverTimestamp()
      });
    } catch (fsError) {
      handleFirestoreError(fsError, OperationType.CREATE, "posts");
    }
    throw error;
  }
};

export const getApiStatus = async () => {
  try {
    const response = await fetch("/api/status");
    if (!response.ok) return "demo";
    const data = await response.json();
    return data.mode || "demo";
  } catch {
    return "demo";
  }
};

export const topUpCredits = async (amountCents: number) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    throw error;
  }

  try {
    if (!userSnap.exists()) {
      // Get device fingerprint
      const fp = await fpPromise;
      const result = await fp.get();
      const deviceId = result.visitorId;
      const deviceRef = doc(db, "device_bonuses", deviceId);

      await runTransaction(db, async (transaction) => {
        const deviceSnap = await transaction.get(deviceRef);
        const userSnapInTx = await transaction.get(userRef);

        if (userSnapInTx.exists()) {
          // Already created in another transaction
          transaction.update(userRef, {
            credits: (userSnapInTx.data()?.credits || 0) + amountCents
          });
          return;
        }

        transaction.set(userRef, {
          uid: user.uid,
          email: user.email,
          credits: amountCents,
          isPaid: true,
          createdAt: serverTimestamp(),
          deviceId: deviceId
        });
        transaction.set(doc(collection(db, "transactions")), {
          uid: user.uid,
          email: user.email,
          amountCents,
          type: 'topup',
          createdAt: serverTimestamp()
        });
      });
      await incrementUsage('revenue', amountCents);
    } else {
      await updateDoc(userRef, {
        credits: increment(amountCents),
        isPaid: true
      });
      await logTransaction(amountCents, 'topup');
      await incrementUsage('revenue', amountCents);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    throw error;
  }
};

export const subtractCredits = async (amountCents: number) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    throw error;
  }

  if (!userSnap.exists()) throw new Error("User profile not found");

  const currentCredits = userSnap.data().credits || 0;
  await updateDoc(userRef, {
    credits: Math.max(0, currentCredits - amountCents)
  });
};

export const ensureUserProfile = async () => {
  const user = auth.currentUser;
  if (!user) return;

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    return;
  }

  if (!userSnap.exists()) {
    // Check if free credits are paused
    const configRef = doc(db, "system", "config");
    let pauseFreeCredits = false;
    try {
      const configSnap = await getDoc(configRef);
      if (configSnap.exists()) {
        pauseFreeCredits = configSnap.data().pauseFreeCredits;
      }
    } catch (e) {
      console.warn("Failed to fetch system config, defaulting to no bonus:", e);
      pauseFreeCredits = true;
    }

    // Get device fingerprint
    const fp = await fpPromise;
    const result = await fp.get();
    const deviceId = result.visitorId;
    const deviceRef = doc(db, "device_bonuses", deviceId);

    try {
      await runTransaction(db, async (transaction) => {
        const deviceSnap = await transaction.get(deviceRef);
        const userSnapInTx = await transaction.get(userRef);

        if (userSnapInTx.exists()) return; // Already created

        let initialCredits = 0;
        let claimedBonus = false;

        if (!pauseFreeCredits && !deviceSnap.exists()) {
          // New device, give 20 credits bonus ($2.00 = 200 cents)
          initialCredits = 200;
          claimedBonus = true;
          transaction.set(deviceRef, {
            uid: user.uid,
            claimedAt: serverTimestamp()
          });
        }

        transaction.set(userRef, {
          uid: user.uid,
          email: user.email,
          credit_balance: initialCredits > 0 ? initialCredits / 10 : 0,
          expires_at: initialCredits > 0 ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null,
          credits: initialCredits,
          postCount: 0,
          isPaid: false,
          createdAt: serverTimestamp(),
          connections: {},
          deviceId: deviceId
        });

        if (claimedBonus) {
          transaction.set(doc(collection(db, "transactions")), {
            uid: user.uid,
            email: user.email,
            amountCents: initialCredits,
            type: 'topup',
            note: 'Initial sign-up bonus',
            createdAt: serverTimestamp()
          });
        }
      });
    } catch (error) {
      console.error("Error ensuring user profile:", error);
    }
  }
};

export const deletePost = async (postId: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const postRef = doc(db, "posts", postId);
  let postSnap;
  try {
    postSnap = await getDoc(postRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `posts/${postId}`);
    throw error;
  }

  if (!postSnap.exists()) throw new Error("Post not found");
  if (postSnap.data().uid !== user.uid) throw new Error("Unauthorized to delete this post");

  try {
    await deleteDoc(postRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `posts/${postId}`);
    throw error;
  }
};

export const getSystemConfig = async () => {
  const configRef = doc(db, "system", "config");
  try {
    const configSnap = await getDoc(configRef);
    if (configSnap.exists()) {
      return configSnap.data();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, "system/config");
  }
  // Default config if none exists
  return { pauseFreeCredits: false };
};

export const updateSystemConfig = async (config: { pauseFreeCredits: boolean }) => {
  const configRef = doc(db, "system", "config");
  try {
    await setDoc(configRef, config, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, "system/config");
  }
};

export const getMonthlyUsage = async () => {
  const monthKey = getMonthKey();
  const usageRef = doc(db, "usage", monthKey);
  try {
    const usageSnap = await getDoc(usageRef);
    if (usageSnap.exists()) {
      return usageSnap.data();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `usage/${monthKey}`);
  }
  return { month: monthKey, totalPosts: 0, revenueCents: 0 };
};

export const getTopHeavyHitters = async () => {
  const usersRef = collection(db, "users");
  const q = query(usersRef, orderBy("postCount", "desc"), limit(10));
  try {
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, "users");
    throw error;
  }
};

export const toggleConnection = async (platformId: string, isConnecting: boolean) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    throw error;
  }

  if (!userSnap.exists()) throw new Error("User profile not found");

  const connections = userSnap.data().connections || {};

  if (isConnecting) {
    try {
      // Try to connect via backend API (e.g. Bundle Social)
      const res = await fetch("/api/connect-social", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform: platformId, uid: user.uid })
      });
      const data = await res.json();
      
      if (data.redirectUrl) {
        // Redirect the user to the OAuth URL in a new tab
        window.open(data.redirectUrl, "_blank", "noopener,noreferrer");
        return; // Stop here, don't simulate
      }
    } catch (err) {
      console.warn("Backend connection failed, falling back to simulated connection:", err);
    }

    // Simulate adding a new account if no redirect happened
    const username = user.email?.split("@")[0] || "syphn_user";
    const accounts = Array.isArray(connections[platformId]) ? connections[platformId] : [];
    
    // Create a new account entry
    const newAccount = {
      id: Math.random().toString(36).substring(2, 11),
      username: `${username}_${accounts.length + 1}`,
      connectedAt: new Date().toISOString()
    };
    
    connections[platformId] = [...accounts, newAccount];
  } else {
    // If just "toggled off", we usually only do this if it's a 1:1 mapping.
    // For multiple accounts, we'll use removeAccount() instead.
    // But for safety, let's just clear the platform.
    delete connections[platformId];
  }

  try {
    await updateDoc(userRef, { connections });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    throw error;
  }
};

export const removeAccount = async (platformId: string, accountId: string) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  const userRef = doc(db, "users", user.uid);
  let userSnap;
  try {
    userSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
    throw error;
  }

  if (!userSnap.exists()) throw new Error("User profile not found");

  const connections = userSnap.data().connections || {};
  if (connections[platformId]) {
    if (Array.isArray(connections[platformId])) {
      connections[platformId] = connections[platformId].filter((acc: any) => acc.id !== accountId);
      if (connections[platformId].length === 0) {
        delete connections[platformId];
      }
    } else {
      delete connections[platformId];
    }
  }

  try {
    await updateDoc(userRef, { connections });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    throw error;
  }
};

export const replenishCreditsSecurely = async (purchasedAmount: number) => {
  const user = auth.currentUser;
  if (!user) throw new Error("User not authenticated");

  // WE MUST GO THROUGH SERVER FOR THIS
  const response = await fetch("/api/replenish-credits", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      amount: purchasedAmount,
      uid: user.uid
    })
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Replenishment failed");
  return data;
};

export const getAdminMetrics = async () => {
  const user = auth.currentUser;
  if (user?.email?.toLowerCase() !== 'ghozt.app@gmail.com') throw new Error("Unauthorized");

  try {
    // Fetch from payments collection
    const paymentsRef = collection(db, "payments");
    const paymentsSnap = await getDocs(paymentsRef);
    const totalRevenueUsd = paymentsSnap.docs.reduce((acc, doc) => acc + (doc.data().amount_usd || 0), 0);

    // Get this month usage
    const monthKey = getMonthKey();
    const usageRef = doc(db, "usage", monthKey);
    const usageSnap = await getDoc(usageRef);
    const totalPosts = usageSnap.exists() ? usageSnap.data().totalPosts : 0;

    const apiUsagePercent = (totalPosts / 10000) * 100;
    
    // Net Profit: Total Revenue minus $100 (API cost) and 3% Stripe fees
    const stripeFees = totalRevenueUsd * 0.03;
    const netProfit = totalRevenueUsd - 100 - stripeFees;

    return {
      totalRevenueUsd,
      apiUsagePercent,
      netProfit,
      totalPosts
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, "admin/metrics");
    throw error;
  }
};
